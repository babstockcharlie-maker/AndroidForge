package com.example.sr7013remote

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.Socket
import java.io.BufferedInputStream
import java.io.OutputStream
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.roundToInt

private val Silver = Color(0xFFD5D1C9)
private val SilverLight = Color(0xFFF0ECE4)
private val Walnut = Color(0xFF63351F)
private val WalnutLight = Color(0xFF9A5B34)
private val Ink = Color(0xFF111214)
private val Blue = Color(0xFF159BEF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(49, 28, 20)
        window.navigationBarColor = android.graphics.Color.rgb(25, 20, 17)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Blue, surface = Ink, background = Walnut)) { RemoteScreen() } }
    }
}

private class ReceiverController(context: Context) {
    private val prefs = context.getSharedPreferences("receiver", Context.MODE_PRIVATE)
    var host: String
        get() = prefs.getString("host", "192.168.0.3") ?: "192.168.0.3"
        set(value) { prefs.edit().putString("host", value.trim()).apply() }

    suspend fun command(command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val encoded = URLEncoder.encode(command, StandardCharsets.UTF_8.name()).replace("+", "%20")
            val conn = (URL("http://$address:8080/goform/formiPhoneAppDirect.xml?$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 2500; readTimeout = 2500; useCaches = false
            }
            try { val code = conn.responseCode; if (code !in 200..299) error("Receiver returned HTTP $code"); conn.inputStream.use { it.readBytes() } }
            finally { conn.disconnect() }
        }
    }

    suspend fun readStatus(zone: String): Result<String> = withContext(Dispatchers.IO) {
        val address = host.trim()
        runCatching {
            val queries = when(zone) { "Main Zone" -> listOf("PW?", "MV?", "MU?", "SI?", "MS?"); "JBL Deck" -> listOf("Z2?", "Z2MU?"); else -> listOf("Z3?", "Z3MU?") }
            Socket().use { socket ->
                socket.connect(java.net.InetSocketAddress(address, 23), 1800); socket.soTimeout = 700
                val out: OutputStream = socket.getOutputStream(); val input = BufferedInputStream(socket.getInputStream()); val lines = mutableListOf<String>()
                queries.forEach { q ->
                    out.write((q + "\r").toByteArray(StandardCharsets.US_ASCII)); out.flush()
                    val end = System.currentTimeMillis() + 350; val sb = StringBuilder()
                    while (System.currentTimeMillis() < end) try { val b = input.read(); if (b < 0) break; if (b == 13 || b == 10) { if (sb.isNotEmpty()) { lines.add(sb.toString()); sb.setLength(0) } } else if (b in 32..126) sb.append(b.toChar()) } catch (_: java.net.SocketTimeoutException) { break }
                    if (sb.isNotEmpty()) lines.add(sb.toString())
                }
                if (lines.isEmpty()) error("No reply on TCP port 23. Check Network Control on the receiver.")
                lines.distinct().joinToString("\n")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteScreen() {
    val context = LocalContext.current
    val controller = remember { ReceiverController(context) }
    val scope = rememberCoroutineScope()
    var ip by remember { mutableStateOf(controller.host) }
    var settingsOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Ready • connect to your Marantz receiver") }
    var status by remember { mutableStateOf("Tap Refresh to read the receiver") }
    var selectedZone by remember { mutableStateOf("Main Zone") }
    var zoneMenu by remember { mutableStateOf(false) }
    var sourceMenu by remember { mutableStateOf(false) }
    var mainSource by remember { mutableStateOf("CBL/SAT") }
    var deckSource by remember { mutableStateOf("NET") }
    var zone3Source by remember { mutableStateOf("CBL/SAT") }
    var sliderDb by remember { mutableFloatStateOf(-55f) }
    var bass by remember { mutableFloatStateOf(0f) }
    var treble by remember { mutableFloatStateOf(0f) }
    var outdoorFollow by remember { mutableStateOf(true) }
    val inputs = listOf("CBL/SAT" to "SAT/CBL", "Blu-ray" to "BD", "Game" to "GAME", "Media Player" to "MPLAY", "TV Audio" to "TV", "AUX1" to "AUX1", "Bluetooth" to "BT", "HEOS / Network" to "NET")

    fun send(cmd: String, label: String = cmd) { scope.launch { busy = true; message = "Sending $label…"; val r = controller.command(cmd); message = r.fold({ "$label • command accepted by receiver" }, { "Could not send $label: ${it.message}" }); busy = false } }
    fun sourceCommand(source: String): String = when(selectedZone) { "Main Zone" -> when(source) { "SAT/CBL" -> "SICBL"; "BD" -> "SIBD"; "GAME" -> "SIGAME"; "MPLAY" -> "SIMPLAY"; "TV" -> "SITV"; "AUX1" -> "SIAUX1"; "BT" -> "SIBT"; else -> "SINET" }; "JBL Deck" -> "Z2$source"; else -> "Z3$source" }
    fun sendVolume(db: Float) {
        val raw = if (selectedZone == "Main Zone") ((db + 80f) * 10f).roundToInt().coerceIn(5, 980).toString().padStart(3, '0') else (db + 80f).roundToInt().coerceIn(0, 98).toString().padStart(2, '0')
        val cmd = when(selectedZone) { "Main Zone" -> "MV$raw"; "JBL Deck" -> "Z2$raw"; else -> "Z3$raw" }
        send(cmd, "$selectedZone volume ${"%.1f".format(java.util.Locale.US, db)} dB")
    }
    val zonePrefix = when(selectedZone) { "Main Zone" -> ""; "JBL Deck" -> "Z2"; else -> "Z3" }
    val sourceSelected = when(selectedZone) { "Main Zone" -> mainSource; "JBL Deck" -> deckSource; else -> zone3Source }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF241713), Color(0xFF754329), Color(0xFF2A1A14))))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // walnut rails and brushed aluminium chassis
            Column(Modifier.fillMaxWidth().border(2.dp, Color(0xFF24130D), RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF3B1E12), Color(0xFFB8794A), Color(0xFF60331F), Color(0xFFB8794A), Color(0xFF3B1E12))), RoundedCornerShape(24.dp)).padding(horizontal = 10.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFFECE7DD), Color(0xFFBEB9B0), Color(0xFFE4DFD5))), RoundedCornerShape(14.dp)).drawBehind {
                        val step = 3.dp.toPx(); var y = 0f
                        while (y < size.height) { drawLine(Color.White.copy(alpha = 0.10f), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 0.45f); y += step }
                    }.border(2.dp, Color(0xFF282522), RoundedCornerShape(14.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("✣", color = Color(0xFF33302C), fontSize = 25.sp)
                        Text("marantz®", color = Color(0xFF090909), fontSize = 32.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Serif, letterSpacing = 1.sp)
                        TextButton(onClick = { settingsOpen = !settingsOpen }) { Text("⚙", color = Ink, fontSize = 25.sp) }
                    }
                    Text("SR7013  REMOTE", color = Color(0xFF171514), fontFamily = FontFamily.Serif, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    // zone selector
                    Row(Modifier.fillMaxWidth().background(Color(0xFF08090B), RoundedCornerShape(12.dp)).border(2.dp, Color(0xFF282727), RoundedCornerShape(12.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Main Zone", "JBL Deck").forEach { z -> ZoneTab(z, selectedZone == z, Modifier.weight(1f)) { selectedZone = z } }
                        Box(Modifier.weight(1f)) {
                            ZoneTab("Zone 3", selectedZone == "Zone 3", Modifier.fillMaxWidth()) { selectedZone = "Zone 3" }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    // status display
                    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF08090B), Color(0xFF202124))), RoundedCornerShape(13.dp)).border(2.dp, Color(0xFF77736D), RoundedCornerShape(13.dp)).padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("POWER:  ${if (status.contains("OFF", true) || status.contains("STANDBY", true)) "—" else "READY"}", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("$selectedZone", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("INPUT:  $sourceSelected", color = Color(0xFFE8E5E0), fontSize = 14.sp)
                        Text(status, color = Color(0xFFB8C4CD), fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3)
                        TextButton(onClick = { scope.launch { status = "Reading receiver…"; status = controller.readStatus(selectedZone).fold({ parseStatus(it, selectedZone) }, { "Status unavailable: ${it.message}" }) } }, modifier = Modifier.align(Alignment.End)) { Text("↻  REFRESH STATUS", color = Blue, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(12.dp))
                    // volume inset
                    InsetPanel("VOLUME") {
                        Text("${"%.1f".format(java.util.Locale.US, sliderDb)} dB", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(value = sliderDb, onValueChange = { sliderDb = it }, onValueChangeFinished = { sendVolume(sliderDb) }, valueRange = -79.5f..18f, colors = SliderDefaults.colors(thumbColor = SilverLight, activeTrackColor = Blue, inactiveTrackColor = Color(0xFF77716A)))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("−79.5 dB", color = Color.White, fontSize = 11.sp); Text("+18 dB", color = Color.White, fontSize = 11.sp) }
                    }
                    Spacer(Modifier.height(12.dp))
                    // source selector
                    InsetPanel("INPUT SOURCE") {
                        Box {
                            DarkButton("${sourceLabel(sourceSelected)}  ▾", Modifier.fillMaxWidth()) { sourceMenu = true }
                            DropdownMenu(expanded = sourceMenu, onDismissRequest = { sourceMenu = false }) {
                                inputs.forEach { (label, code) -> DropdownMenuItem(text = { Text(label) }, onClick = { sourceMenu = false; when(selectedZone) { "Main Zone" -> mainSource = code; "JBL Deck" -> deckSource = code; else -> zone3Source = code }; send(sourceCommand(code), "$selectedZone source $label") }) }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    // tactile power, mute and volume
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        RoundControl("⏻", "POWER") { send(if (selectedZone == "Main Zone") "PWON" else "${zonePrefix}ON", "$selectedZone power on") }
                        RoundControl("◀×", "MUTE") { send(if (selectedZone == "Main Zone") "MUON" else "${zonePrefix}MUON", "$selectedZone mute") }
                        RoundControl("−", "VOL −") { send(if (selectedZone == "Main Zone") "MVDOWN" else "${zonePrefix}DOWN", "Volume down") }
                        RoundControl("+", "VOL +") { send(if (selectedZone == "Main Zone") "MVUP" else "${zonePrefix}UP", "Volume up") }
                        RoundControl("Ⅱ", "OFF") { send(if (selectedZone == "Main Zone") "PWSTANDBY" else "${zonePrefix}OFF", "$selectedZone off") }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (selectedZone == "Main Zone") {
                        InsetPanel("BASS  /  TREBLE") {
                            Text("Bass  ${bass.roundToInt()} dB", color = Blue, fontWeight = FontWeight.Bold)
                            Slider(value = bass, onValueChange = { bass = it }, valueRange = -6f..6f, onValueChangeFinished = { val v = (50 + bass.roundToInt()).coerceIn(44,56); send("PSBAS ${v}", "Bass ${bass.roundToInt()} dB") }, colors = SliderDefaults.colors(thumbColor = SilverLight, activeTrackColor = Blue))
                            Text("Treble  ${treble.roundToInt()} dB", color = Blue, fontWeight = FontWeight.Bold)
                            Slider(value = treble, onValueChange = { treble = it }, valueRange = -6f..6f, onValueChangeFinished = { val v = (50 + treble.roundToInt()).coerceIn(44,56); send("PSTRE ${v}", "Treble ${treble.roundToInt()} dB") }, colors = SliderDefaults.colors(thumbColor = SilverLight, activeTrackColor = Blue))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { DarkButton("TONE ON", Modifier.weight(1f)) { send("PSTONE CTRL ON") }; DarkButton("TONE OFF", Modifier.weight(1f)) { send("PSTONE CTRL OFF") } }
                        }
                        Spacer(Modifier.height(12.dp))
                        InsetPanel("SOUND MODE") {
                            val modes = listOf("Stereo" to "MSSTEREO", "Direct" to "MSDIRECT", "Pure Direct" to "MSPURE DIRECT", "Music" to "MSDOLBY SURROUND", "Movie" to "MSDTS NEURAL:X")
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { modes.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { pair.forEach { (label, cmd) -> DarkButton(label, Modifier.weight(1f)) { send(cmd, "Sound mode $label") } } } } }
                        }
                    } else if (selectedZone == "JBL Deck") {
                        InsetPanel("JBL DECK • OUTDOOR") {
                            Text("Power the outdoor speakers and choose their source independently, or follow the Main Zone.", color = Color(0xFFD8D5D0), fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = outdoorFollow, onCheckedChange = { outdoorFollow = it }, colors = CheckboxDefaults.colors(checkedColor = Blue)); Text("Follow Main Zone source", color = Color.White) }
                            DarkButton("START OUTDOOR MUSIC", Modifier.fillMaxWidth()) { scope.launch { busy = true; val p = controller.command("Z2ON"); val s = controller.command(if (outdoorFollow) sourceCommand(mainSource) else "Z2$deckSource"); message = if (p.isSuccess && s.isSuccess) "JBL Deck power and source commands sent" else "Outdoor start failed: ${p.exceptionOrNull()?.message ?: s.exceptionOrNull()?.message}"; busy = false } }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF111214), Color(0xFF292725))), RoundedCornerShape(8.dp)).border(1.dp, Color(0xFF9B9489), RoundedCornerShape(8.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("marantz®", color = SilverLight, fontSize = 27.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Serif)
                        Text("Inspired by Marantz 1060B · Est. 1975", color = Silver, fontFamily = FontFamily.Serif, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            if (settingsOpen) {
                Spacer(Modifier.height(10.dp))
                Column(Modifier.fillMaxWidth().background(Color(0xFF171311), RoundedCornerShape(12.dp)).padding(14.dp)) {
                    Text("RECEIVER CONNECTION", color = SilverLight, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = ip, onValueChange = { ip = it }, label = { Text("Receiver IP address") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Blue, unfocusedBorderColor = Silver))
                    Spacer(Modifier.height(8.dp))
                    DarkButton("SAVE & TEST CONNECTION", Modifier.fillMaxWidth()) { controller.host = ip; send("PW?", "Connection test") }
                }
            }
            Text(message, color = Color(0xFFFFE7CE), fontSize = 12.sp, modifier = Modifier.padding(10.dp), textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun ZoneTab(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (selected) Brush.verticalGradient(listOf(Color(0xFF087BC8), Color(0xFF003B75))) else Brush.verticalGradient(listOf(Color(0xFF343536), Color(0xFF111214)))
    Box(modifier.height(48.dp).clip(RoundedCornerShape(8.dp)).background(bg).border(1.dp, if (selected) Color(0xFF7BD4FF) else Color(0xFF77716B), RoundedCornerShape(8.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center) }
}

@Composable private fun InsetPanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF08090A), Color(0xFF252627))), RoundedCornerShape(13.dp)).border(2.dp, Color(0xFF89847D), RoundedCornerShape(13.dp)).padding(12.dp), content = {
        Text(title, color = Silver, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(6.dp)); content()
    })
}

@Composable private fun DarkButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(9.dp)).background(Brush.verticalGradient(listOf(Color(0xFF555250), Color(0xFF111214)))).border(1.5.dp, Color(0xFFB8B2A9), RoundedCornerShape(9.dp)).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 10.dp), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.Center) }
}

@Composable private fun RoundControl(symbol: String, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }.padding(2.dp)) {
        Box(Modifier.size(54.dp).shadow(4.dp, CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF4B4A48), Color(0xFF090A0B))), CircleShape).border(2.dp, Color(0xFFB7B0A6), CircleShape), contentAlignment = Alignment.Center) { Text(symbol, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(3.dp)); Text(label, color = Ink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

private fun sourceLabel(code: String) = when(code) { "SAT/CBL" -> "CBL/SAT"; "BD" -> "Blu-ray"; "GAME" -> "Game"; "MPLAY" -> "Media Player"; "TV" -> "TV Audio"; "AUX1" -> "AUX1"; "BT" -> "Bluetooth"; else -> "HEOS / Network" }

private fun parseStatus(raw: String, zone: String): String {
    val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() && it != "?" }
    if (lines.isEmpty()) return "No readable status values returned"
    val prefix = when(zone) { "Main Zone" -> "MV"; "JBL Deck" -> "Z2"; else -> "Z3" }
    val volLine = lines.firstOrNull { it.startsWith(prefix) && it.length > prefix.length && it.removePrefix(prefix).firstOrNull()?.isDigit() == true }
    val vol = volLine?.removePrefix(prefix)?.toIntOrNull()?.let { raw -> val scaled = if (zone == "Main Zone") raw / 10.0 else raw.toDouble(); "${"%.1f".format(java.util.Locale.US, scaled - 80.0)} dB" }
    val srcPrefix = if (zone == "Main Zone") "SI" else prefix
    val src = lines.firstOrNull { it.startsWith(srcPrefix) && it.length > srcPrefix.length && it.removePrefix(srcPrefix).firstOrNull()?.isLetter() == true && !it.startsWith("${prefix}MU") }?.removePrefix(srcPrefix)
    return listOfNotNull(vol?.let { "Volume: $it" }, src?.let { "Source: $it" }, lines.firstOrNull { it == "PWON" || it == "Z2ON" || it == "Z3ON" }?.let { "Power: On" }).joinToString("  •  ").ifBlank { lines.joinToString("  ") }
}
