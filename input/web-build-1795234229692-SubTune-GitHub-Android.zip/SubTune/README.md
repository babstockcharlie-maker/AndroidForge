# SubTune v1.0 — Android subwoofer tuning tester

Generates low-level sine tones via the selected Android media output (including Bluetooth A2DP), captures a near-field measurement using the phone microphone, and saves port and cone frequency-response measurements to CSV.

## Build APK using GitHub (phone-only)
1. Create a new **private** GitHub repository, e.g. `SubTune`.
2. Upload **the contents of this ZIP** to the repository root, preserving `.github/workflows/build-apk.yml` (GitHub web upload may hide dot-folders; use GitHub's Add file > Create new file for `.github/workflows/build-apk.yml` if necessary). Alternatively use a GitHub-capable ZIP importer or Git client.
3. In GitHub open **Actions → Build SubTune APK → Run workflow**. Pushes to `main` also trigger the build.
4. Open the completed workflow, download **SubTune-debug-apk**, unzip it, and install `app-debug.apk` on your Android phone (allow installation from your file manager if prompted).

No Gradle wrapper binary is needed; GitHub Actions installs Gradle 8.9.

## Measurement procedure
1. Connect Bluetooth media audio to the amplifier, turn off heater, set amp gain low. Keep the phone's microphone clear.
2. Select **Calibration** and press **Run selected test**. It measures background at 50 Hz, then plays a 50 Hz tone and measures the signal. Check it is clean and sufficiently above background. Do not treat dBFS as calibrated SPL.
3. Select **Port**, place microphone ~1 inch from the centre of the port opening, and run automatic sweep (25, 30, 35, 38, 40, 42, 45, 50, 55, 60 Hz). Keep position steady.
4. Select **Cone**, place microphone ~1 inch from cone near dust cap (no contact), and repeat at unchanged gain.
5. Review results; export CSV using **Share CSV**. A preliminary tuning hint is displayed from the cone dip and port peak, not a calibrated measurement.
6. Manual mode lets you select a frequency from 20–80 Hz and run a single capture; use the Stop button to abort.

## Important limitations
- **No hardware protection:** Start with amplifier volume low, especially below ~35 Hz. Stop if cone excursion becomes excessive or distortion occurs. The app's digital amplitude control is NOT a calibrated SPL limiter.
- Android microphone frequency response, automatic gain control, filtering and Bluetooth routing may skew measurements. The app requests an unprocessed/voice-recognition mic source when available and prefers built-in mic, but cannot guarantee unprocessed audio on every device.
- For stable measurements, keep phone and amp volume, position, and routing fixed. Measurements are dBFS relative to the microphone capture, not dB SPL.
- Port and cone curves cannot be directly interpreted as a perfectly calibrated acoustic transfer function; use cone-motion minimum and port output maximum as corroborating clues.
- This v1 uses a text result log and CSV rather than a plotted graph. A future version can add a graph and finer frequency steps.
- This is a source project for GitHub Actions; the APK is produced by GitHub, not precompiled in this ZIP.
