SR7013 Remote v5.9.1: fixes Kotlin compile error at MetallicTrack by explicitly opting in to ExperimentalMaterial3Api. All v5.9 functionality preserved; AndroidForge build required.
