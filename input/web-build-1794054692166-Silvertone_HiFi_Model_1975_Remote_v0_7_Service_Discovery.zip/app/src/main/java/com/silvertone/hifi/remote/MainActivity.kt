package com.silvertone.hifi.remote

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.CancellationException
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import java.net.InetSocketAddress
import java.net.HttpURLConnection
import java.net.Socket
import java.io.BufferedInputStream
import java.io.OutputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.roundToInt

private val Silver = Color(0xFFD5D1C9)
private val SilverLight = Color(0xFFF0ECE4)
private val Walnut = Color(0xFF63351F)
private val WalnutLight = Color(0xFF9A5B34)
private val Ink = Color(0xFF111214)
private val Blue = Color(0xFF159BEF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(49, 28, 20)
        window.navigationBarColor = android.graphics.Color.rgb(25, 20, 17)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Blue, surface = Ink, background = Walnut)) { RemoteScreen() } }
    }
}

private class ReceiverController(context: Context) {
    private val prefs = context.getSharedPreferences("receiver", Context.MODE_PRIVATE)
    var host: String
        get() = prefs.getString("host", "192.168.0.3") ?: "192.168.0.3"
        set(value) { prefs.edit().putString("host", value.trim()).apply() }

    suspend fun command(command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val encoded = URLEncoder.encode(command, StandardCharsets.UTF_8.name()).replace("+", "%20")
            val conn = (URL("http://$address:8080/goform/formiPhoneAppDirect.xml?$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 2500; readTimeout = 2500; useCaches = false
            }
            try { val code = conn.responseCode; if (code !in 200..299) error("Receiver returned HTTP $code"); conn.inputStream.use { it.readBytes() }; Unit }
            finally { conn.disconnect() }
        }
    }

    // Experimental read-only Denon/Marantz AJAX endpoint; availability varies by receiver/firmware.
    // Only parse documented front speaker indexes 0 and 1. Never write calibration settings.
    suspend fun readSpeakerDistances(): Result<Pair<Float, Float>> = withContext(Dispatchers.IO) {
        runCatching {
            val address = host.trim()
            require(address.isNotEmpty()) { "Set receiver IP address first" }
            val url = URL("http://$address:11080/ajax/speakers/get_config?type=4")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 2000; readTimeout = 2500; useCaches = false
            }
            val xml = try {
                if (conn.responseCode != 200) error("HTTP ${conn.responseCode} on port 11080")
                conn.inputStream.bufferedReader().use { it.readText().take(100000) }
            } finally { conn.disconnect() }
            // Harden XML parser against external entities and unexpected document types.
            val factory = javax.xml.parsers.DocumentBuilderFactory.newInstance()
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false)
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            factory.isXIncludeAware = false
            factory.isExpandEntityReferences = false
            val doc = factory.newDocumentBuilder().parse(org.xml.sax.InputSource(java.io.StringReader(xml)))
            val roots = doc.getElementsByTagName("Distances")
            if (roots.length == 0) error("Receiver did not return a Distances document")
            val root = roots.item(0) as org.w3c.dom.Element
            val unit = root.getElementsByTagName("Unit").item(0)?.textContent?.trim()
            if (unit != "1" && unit != "2") error("Unrecognized receiver distance unit: $unit")
            val entries = root.getElementsByTagName("Speaker")
            val found = mutableMapOf<String, Float>()
            for (i in 0 until entries.length) {
                val e = entries.item(i) as? org.w3c.dom.Element ?: continue
                val index = e.getAttribute("index")
                if (index != "0" && index != "1") continue
                val raw = e.textContent.trim().toFloatOrNull() ?: continue
                val measurement = raw / 100f
                val meters = if (unit == "1") measurement * 0.3048f else measurement
                if (meters in 0.1f..30f) found[index] = meters
            }
            val fl = found["0"] ?: error("Front Left distance missing in receiver response")
            val fr = found["1"] ?: error("Front Right distance missing in receiver response")
            Pair(fl, fr)
        }
    }

    suspend fun readStatus(zone: String): Result<String> = withContext(Dispatchers.IO) {
        val address = host.trim()
        runCatching {
            val queries = when(zone) { "Main Zone" -> listOf("PW?", "MV?", "MU?", "SI?", "MS?"); "Zone 2" -> listOf("Z2?", "Z2MU?"); else -> listOf("Z3?", "Z3MU?") }
            Socket().use { socket ->
                socket.connect(java.net.InetSocketAddress(address, 23), 1800); socket.soTimeout = 700
                val out: OutputStream = socket.getOutputStream(); val input = BufferedInputStream(socket.getInputStream()); val lines = mutableListOf<String>()
                queries.forEach { q ->
                    out.write((q + "\r").toByteArray(StandardCharsets.US_ASCII)); out.flush()
                    val end = System.currentTimeMillis() + 350; val sb = StringBuilder()
                    while (System.currentTimeMillis() < end) try { val b = input.read(); if (b < 0) break; if (b == 13 || b == 10) { if (sb.isNotEmpty()) { lines.add(sb.toString()); sb.setLength(0) } } else if (b in 32..126) sb.append(b.toChar()) } catch (_: java.net.SocketTimeoutException) { break }
                    if (sb.isNotEmpty()) lines.add(sb.toString())
                }
                if (lines.isEmpty()) error("No reply on TCP port 23. Check Network Control on the receiver.")
                lines.distinct().joinToString("\n")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteScreen() {
    val context = LocalContext.current
    val controller = remember { ReceiverController(context) }
    val scope = rememberCoroutineScope()
    var ip by remember { mutableStateOf(controller.host) }
    var settingsOpen by remember { mutableStateOf(false) }
    var speakerSetupOpen by remember { mutableStateOf(false) }
    var diagnosticsOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Ready • connect to your audio receiver") }
    var status by remember { mutableStateOf("Tap Refresh to read the receiver") }
    var selectedZone by remember { mutableStateOf("Main Zone") }
    var zoneMenu by remember { mutableStateOf(false) }
    var sourceMenu by remember { mutableStateOf(false) }
    var mainSource by remember { mutableStateOf("CBL/SAT") }
    var deckSource by remember { mutableStateOf("NET") }
    var zone3Source by remember { mutableStateOf("CBL/SAT") }
    var sliderDb by remember { mutableFloatStateOf(-55f) }
    var bass by remember { mutableFloatStateOf(0f) }
    var treble by remember { mutableFloatStateOf(0f) }
    val powerStates = remember { mutableStateMapOf<String, Boolean>() }
    val inputs = listOf("CBL/SAT" to "SAT/CBL", "Blu-ray" to "BD", "Game" to "GAME", "Media Player" to "MPLAY", "TV Audio" to "TV", "AUX1" to "AUX1", "Bluetooth" to "BT", "HEOS / Network" to "NET")

    fun applyReceiverStatus(raw: String, zone: String) {
        if (zone != selectedZone) return
        status = parseStatus(raw, zone)
        parseVolumeDb(raw, zone)?.let { sliderDb = it }
        parsePowerState(raw, zone)?.let { powerStates[zone] = it }
        parseSourceCode(raw, zone)?.let { code ->
            when(zone) {
                "Main Zone" -> mainSource = code
                "Zone 2" -> deckSource = code
                else -> zone3Source = code
            }
        }
    }
    fun refresh(zone: String = selectedZone) {
        scope.launch {
            val result = controller.readStatus(zone)
            result.onSuccess { applyReceiverStatus(it, zone) }
                .onFailure { if (zone == selectedZone) status = "Status unavailable: ${it.message}" }
        }
    }
    fun send(cmd: String, label: String = cmd, powerChange: Boolean? = null) {
        val zone = selectedZone
        scope.launch {
            busy = true
            message = "Sending $label…"
            val r = controller.command(cmd)
            message = r.fold({ "$label • command accepted by receiver" }, { "Could not send $label: ${it.message}" })
            if (r.isSuccess) {
                if (powerChange != null) powerStates[zone] = powerChange
                delay(350)
                refresh(zone)
            }
            busy = false
        }
    }
    LaunchedEffect(selectedZone) {
        status = "Reading $selectedZone…"
        refresh(selectedZone)
    }
    fun sourceCommand(source: String): String = when(selectedZone) { "Main Zone" -> when(source) { "SAT/CBL" -> "SICBL"; "BD" -> "SIBD"; "GAME" -> "SIGAME"; "MPLAY" -> "SIMPLAY"; "TV" -> "SITV"; "AUX1" -> "SIAUX1"; "BT" -> "SIBT"; else -> "SINET" }; "Zone 2" -> "Z2$source"; else -> "Z3$source" }
    fun sendVolume(db: Float) {
        // Main Zone: MVxx for whole steps, MVxx5 for half steps (e.g. MV025 = -77.5 dB).
        // Zone 2/3: retain the known-working two-digit absolute-volume commands.
        val raw = if (selectedZone == "Main Zone") {
            val halfSteps = ((db + 80f) * 2f).roundToInt().coerceIn(1, 196)
            val whole = halfSteps / 2
            whole.toString().padStart(2, '0') + if (halfSteps % 2 == 1) "5" else ""
        } else (db + 80f).roundToInt().coerceIn(0, 98).toString().padStart(2, '0')
        val cmd = when(selectedZone) { "Main Zone" -> "MV$raw"; "Zone 2" -> "Z2$raw"; else -> "Z3$raw" }
        send(cmd, "$selectedZone volume ${"%.1f".format(java.util.Locale.US, db)} dB")
    }
    val zonePrefix = when(selectedZone) { "Main Zone" -> ""; "Zone 2" -> "Z2"; else -> "Z3" }
    val sourceSelected = when(selectedZone) { "Main Zone" -> mainSource; "Zone 2" -> deckSource; else -> zone3Source }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF241713), Color(0xFF754329), Color(0xFF2A1A14))))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // walnut rails and brushed aluminium chassis
            Column(Modifier.fillMaxWidth().border(2.dp, Color(0xFF24130D), RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF3B1E12), Color(0xFFB8794A), Color(0xFF60331F), Color(0xFFB8794A), Color(0xFF3B1E12))), RoundedCornerShape(24.dp)).padding(horizontal = 10.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).paint(painterResource(id = R.drawable.brushed_aluminum), contentScale = ContentScale.FillBounds).drawBehind {
                        val step = 3.dp.toPx(); var y = 0f
                        while (y < size.height) { drawLine(Color.White.copy(alpha = 0.10f), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 0.45f); y += step }
                    }.border(2.dp, Color(0xFF282522), RoundedCornerShape(14.dp)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        BoltHead()
                        Image(painter = painterResource(R.drawable.silvertone_wordmark), contentDescription = "Silvertone Hi-Fi", modifier = Modifier.width(240.dp).height(70.dp), contentScale = ContentScale.Fit)
                        BoltHead()
                    }
                    Image(painter = painterResource(R.drawable.model_1975_script), contentDescription = "Model 1975 Remote", modifier = Modifier.fillMaxWidth().height(34.dp), contentScale = ContentScale.Fit)
                    Spacer(Modifier.height(9.dp))
                    if (diagnosticsOpen) {
                        DiagnosticsPage(controller = controller, onBack = { diagnosticsOpen = false })
                    } else if (speakerSetupOpen) {
                        SpeakerSetupPage(controller = controller, onBack = { speakerSetupOpen = false })
                    } else {
                    // zone selector
                    Row(Modifier.fillMaxWidth().background(Color(0xFF08090B), RoundedCornerShape(12.dp)).border(2.dp, Color(0xFF282727), RoundedCornerShape(12.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Main Zone", "Zone 2").forEach { z -> ZoneTab(z, selectedZone == z, Modifier.weight(1f)) { selectedZone = z } }
                        Box(Modifier.weight(1f)) {
                            ZoneTab("Zone 3", selectedZone == "Zone 3", Modifier.fillMaxWidth()) { selectedZone = "Zone 3" }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    // status display
                    Column(Modifier.fillMaxWidth().heightIn(min = 101.dp).background(Brush.verticalGradient(listOf(Color(0xFF08090B), Color(0xFF202124))), RoundedCornerShape(13.dp)).border(2.dp, Color(0xFF77736D), RoundedCornerShape(13.dp)).padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("POWER:  ${when(powerStates[selectedZone]) { true -> "ON"; false -> "OFF"; null -> "UNKNOWN" }}", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("$selectedZone", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("INPUT:  $sourceSelected", color = Color(0xFFE8E5E0), fontSize = 14.sp)
                        Text(status, color = Color(0xFFB8C4CD), fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3)
                        TextButton(onClick = { scope.launch { status = "Reading receiver…"; refresh(selectedZone) } }, modifier = Modifier.align(Alignment.End)) { Text("↻  REFRESH STATUS", color = Blue, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(9.dp))
                    // volume inset
                    InsetPanel("VOLUME", minHeight = 119.dp) {
                        Text("${"%.1f".format(java.util.Locale.US, sliderDb)} dB", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Slider(value = sliderDb, onValueChange = { sliderDb = it }, onValueChangeFinished = { sendVolume(sliderDb) }, thumb = { MetallicThumb() }, track = { MetallicTrack(it) }, valueRange = -79.5f..18f, colors = SliderDefaults.colors(thumbColor = SilverLight, activeTrackColor = Blue, inactiveTrackColor = Color(0xFF77716A)))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("−79.5 dB", color = Color.White, fontSize = 11.sp); Text("+18 dB", color = Color.White, fontSize = 11.sp) }
                    }
                    Spacer(Modifier.height(9.dp))
                    // source selector
                    InsetPanel("INPUT SOURCE") {
                        Box {
                            DarkButton("${sourceLabel(sourceSelected)}  ▾", Modifier.fillMaxWidth()) { sourceMenu = true }
                            DropdownMenu(expanded = sourceMenu, onDismissRequest = { sourceMenu = false }) {
                                inputs.forEach { (label, code) -> DropdownMenuItem(text = { Text(label) }, onClick = { sourceMenu = false; when(selectedZone) { "Main Zone" -> mainSource = code; "Zone 2" -> deckSource = code; else -> zone3Source = code }; send(sourceCommand(code), "$selectedZone source $label") }) }
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    // tactile power, mute and volume
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        RoundControl("POWER_ICON", "POWER", lit = powerStates[selectedZone] == true) {
                            val turnOn = powerStates[selectedZone] != true
                            send(if (selectedZone == "Main Zone") (if (turnOn) "PWON" else "PWSTANDBY") else "${zonePrefix}${if (turnOn) "ON" else "OFF"}", "$selectedZone power ${if (turnOn) "on" else "off"}", powerChange = turnOn)
                        }
                        RoundControl("◀×", "MUTE") { send(if (selectedZone == "Main Zone") "MUON" else "${zonePrefix}MUON", "$selectedZone mute") }
                        RoundControl("−", "VOL −") { send(if (selectedZone == "Main Zone") "MVDOWN" else "${zonePrefix}DOWN", "Volume down") }
                        RoundControl("+", "VOL +") { send(if (selectedZone == "Main Zone") "MVUP" else "${zonePrefix}UP", "Volume up") }
                    }
                    Spacer(Modifier.height(9.dp))
                    if (selectedZone == "Main Zone") {
                        InsetPanel("TONE") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Bass", color = Color.White, fontFamily = FontFamily.Serif, fontSize = 18.sp)
                                    Text("${bass.roundToInt()} dB", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Slider(value = bass, onValueChange = { bass = it }, valueRange = -6f..6f, thumb = { MetallicThumb(small = true) }, track = { MetallicTrack(it) }, onValueChangeFinished = { val v = (50 + bass.roundToInt()).coerceIn(44,56); send("PSBAS ${v}", "Bass ${bass.roundToInt()} dB") }, colors = SliderDefaults.colors(activeTrackColor = Blue, inactiveTrackColor = Silver))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("−6", color = Silver, fontSize = 10.sp); Text("+6", color = Silver, fontSize = 10.sp) }
                                }
                                Box(Modifier.width(1.dp).height(102.dp).background(Silver.copy(alpha = 0.65f)))
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Treble", color = Color.White, fontFamily = FontFamily.Serif, fontSize = 18.sp)
                                    Text("${treble.roundToInt()} dB", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Slider(value = treble, onValueChange = { treble = it }, valueRange = -6f..6f, thumb = { MetallicThumb(small = true) }, track = { MetallicTrack(it) }, onValueChangeFinished = { val v = (50 + treble.roundToInt()).coerceIn(44,56); send("PSTRE ${v}", "Treble ${treble.roundToInt()} dB") }, colors = SliderDefaults.colors(activeTrackColor = Blue, inactiveTrackColor = Silver))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("−6", color = Silver, fontSize = 10.sp); Text("+6", color = Silver, fontSize = 10.sp) }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { DarkButton("TONE ON", Modifier.weight(1f)) { send("PSTONE CTRL ON") }; DarkButton("TONE OFF", Modifier.weight(1f)) { send("PSTONE CTRL OFF") } }
                        }
                        Spacer(Modifier.height(9.dp))
                        InsetPanel("SOUND MODE") {
                            val modes = listOf("Stereo" to "MSSTEREO", "Direct" to "MSDIRECT", "Pure Direct" to "MSPURE DIRECT", "Music" to "MSDOLBY SURROUND", "Movie" to "MSDTS NEURAL:X")
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                modes.forEach { (label, cmd) ->
                                    Box(Modifier.weight(1f).heightIn(min = 49.dp).clip(RoundedCornerShape(7.dp))
                                        .background(Brush.verticalGradient(listOf(Color(0xFF555250), Color(0xFF111214))))
                                        .border(1.dp, Color(0xFFB8B2A9), RoundedCornerShape(7.dp))
                                        .clickable { send(cmd, "Sound mode $label") }.padding(horizontal = 2.dp, vertical = 6.dp),
                                        contentAlignment = Alignment.Center) {
                                        Text(label, color = Color.White, fontFamily = FontFamily.Serif,
                                            fontSize = 11.sp, lineHeight = 12.sp, textAlign = TextAlign.Center,
                                            fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    DarkButton("◖))  SPEAKER SETUP", Modifier.fillMaxWidth()) { speakerSetupOpen = true }
                    Spacer(Modifier.height(7.dp))
                    DarkButton("⌁  RECEIVER DIAGNOSTICS", Modifier.fillMaxWidth()) { diagnosticsOpen = true }
                    Spacer(Modifier.height(9.dp))
                    } // end remote controls; speaker setup has its own page
                    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF111214), Color(0xFF292725))), RoundedCornerShape(8.dp)).border(1.dp, Color(0xFF9B9489), RoundedCornerShape(8.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(painter = painterResource(R.drawable.silvertone_footer_wordmark), contentDescription = "Silvertone Hi-Fi", modifier = Modifier.width(226.dp).height(60.dp), contentScale = ContentScale.Fit)
                        Text("Hi-Fi  •  Heritage Sound", color = Silver, fontFamily = FontFamily.Serif, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.Bottom) {
                            listOf(8, 15, 24, 12, 20, 28, 17, 10, 23, 15, 8).forEach { h ->
                                Box(Modifier.padding(horizontal = 2.dp).width(5.dp).height(h.dp).background(Color(0xFFFFBE62), RoundedCornerShape(1.dp)))
                            }
                        }
                        Spacer(Modifier.height(3.dp))
                        TextButton(onClick = { settingsOpen = !settingsOpen }) {
                            Text("RECEIVER ADDRESS", color = Silver, fontFamily = FontFamily.Serif, fontSize = 11.sp)
                        }
                    }
                }
            }
            if (settingsOpen && !speakerSetupOpen && !diagnosticsOpen) {
                Spacer(Modifier.height(8.dp))
                Column(Modifier.fillMaxWidth().background(Color(0xFF171311), RoundedCornerShape(12.dp)).padding(14.dp)) {
                    Text("RECEIVER CONNECTION", color = SilverLight, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = ip, onValueChange = { ip = it }, label = { Text("Receiver IP address") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Blue, unfocusedBorderColor = Silver))
                    Spacer(Modifier.height(8.dp))
                    DarkButton("SAVE & TEST CONNECTION", Modifier.fillMaxWidth()) { controller.host = ip; send("PW?", "Connection test") }
                }
            }
            Text(message, color = Color(0xFFFFE7CE), fontSize = 12.sp, modifier = Modifier.padding(10.dp), textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun BoltHead() {
    // Decorative hexagonal bolt, inspired by vintage hi-fi hardware.
    Canvas(Modifier.size(34.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = size.minDimension * 0.45f
        val hex = Path().apply {
            for (i in 0..5) {
                val angle = (PI / 3.0 * i - PI / 6.0)
                val x = cx + radius * cos(angle).toFloat()
                val y = cy + radius * sin(angle).toFloat()
                if (i == 0) moveTo(x,y) else lineTo(x,y)
            }
            close()
        }
        drawPath(hex, brush = Brush.linearGradient(listOf(Color(0xFF615C55), Color(0xFFF7F3EA), Color(0xFF78716B))))
        drawPath(hex, Color(0xFF403B37), style = Stroke(width = 1.2.dp.toPx()))
        drawCircle(Color(0xFF4E4944), radius * .70f, center = Offset(cx,cy))
        drawCircle(brush = Brush.linearGradient(listOf(Color(0xFFFAF8F3), Color(0xFFB7B2A9), Color(0xFFE8E4DD), Color(0xFF8A857D))),
            radius = radius * .61f, center = Offset(cx,cy))
        drawCircle(Color.White.copy(alpha = .48f), radius * .47f, center = Offset(cx,cy), style = Stroke(width = .7.dp.toPx()))
    }
}

@Composable private fun PowerGlyph() {
    Canvas(Modifier.size(30.dp)) {
        val w = size.width
        val h = size.height
        drawArc(Color.White, startAngle = -47f, sweepAngle = 274f, useCenter = false,
            topLeft = Offset(w * .15f, h * .15f),
            size = androidx.compose.ui.geometry.Size(w * .70f, h * .70f),
            style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round))
        drawLine(Color.White, Offset(w * .5f, h * .05f), Offset(w * .5f, h * .48f),
            strokeWidth = 3.2.dp.toPx(), cap = StrokeCap.Round)
    }
}

@Composable private fun ZoneTab(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (selected) Brush.verticalGradient(listOf(Color(0xFF087BC8), Color(0xFF003B75))) else Brush.verticalGradient(listOf(Color(0xFF343536), Color(0xFF111214)))
    Box(modifier.height(46.dp).clip(RoundedCornerShape(8.dp)).background(bg).border(1.dp, if (selected) Color(0xFF7BD4FF) else Color(0xFF77716B), RoundedCornerShape(8.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Serif, fontSize = 15.sp, textAlign = TextAlign.Center) }
}

@Composable private fun InsetPanel(title: String, minHeight: Dp = 0.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(min = minHeight).background(Brush.verticalGradient(listOf(Color(0xFF08090A), Color(0xFF252627))), RoundedCornerShape(13.dp)).border(2.dp, Color(0xFF89847D), RoundedCornerShape(13.dp)).padding(12.dp), content = {
        Text(title, color = Silver, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, letterSpacing = 1.0.sp)
        Spacer(Modifier.height(6.dp)); content()
    })
}

@Composable private fun DarkButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(9.dp)).background(Brush.verticalGradient(listOf(Color(0xFF555250), Color(0xFF111214)))).border(1.5.dp, Color(0xFFB8B2A9), RoundedCornerShape(9.dp)).clickable { onClick() }.padding(horizontal = 8.dp, vertical = 10.dp), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Serif, fontSize = 14.sp, textAlign = TextAlign.Center) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun MetallicTrack(state: androidx.compose.material3.SliderState) {
    val fraction = ((state.value - state.valueRange.start) /
        (state.valueRange.endInclusive - state.valueRange.start)).coerceIn(0f, 1f)
    Canvas(Modifier.fillMaxWidth().height(9.dp)) {
        val r = size.height / 2f
        drawRoundRect(Color(0xFFBEBBB6), cornerRadius = androidx.compose.ui.geometry.CornerRadius(r))
        drawRoundRect(Blue, size = androidx.compose.ui.geometry.Size(size.width * fraction, size.height),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r))
    }
}

@Composable private fun MetallicThumb(small: Boolean = false) {
    Box(
        Modifier.size(if (small) 28.dp else 36.dp).shadow(5.dp, CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF88847D), Color(0xFFF9F7F2), Color(0xFFB0AAA1), Color(0xFFEEEAE4))), CircleShape)
            .border(2.dp, Color(0xFF6D6760), CircleShape)
            .drawBehind {
                drawCircle(Color.White.copy(alpha = 0.45f), radius = size.minDimension * 0.32f, style = Stroke(width = 1.dp.toPx()))
            }
    )
}

@Composable private fun RoundControl(symbol: String, label: String, lit: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }.padding(2.dp)) {
        Box(Modifier.size(52.dp).shadow(if (lit) 9.dp else 4.dp, CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF4B4A48), Color(0xFF090A0B))), CircleShape).border(if (lit) 3.dp else 2.dp, if (lit) Color(0xFF22B8FF) else Color(0xFFB7B0A6), CircleShape), contentAlignment = Alignment.Center) { if (symbol == "POWER_ICON") PowerGlyph() else Text(symbol, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(3.dp)); Text(label, color = Ink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

private fun sourceLabel(code: String) = when(code) { "SAT/CBL" -> "CBL/SAT"; "BD" -> "Blu-ray"; "GAME" -> "Game"; "MPLAY" -> "Media Player"; "TV" -> "TV Audio"; "AUX1" -> "AUX1"; "BT" -> "Bluetooth"; "NET" -> "HEOS / Network"; else -> code }

private fun parseSourceCode(raw: String, zone: String): String? {
    val prefix = when(zone) { "Main Zone" -> "SI"; "Zone 2" -> "Z2"; else -> "Z3" }
    val known = setOf("SAT/CBL", "CBL", "BD", "GAME", "MPLAY", "TV", "AUX1", "BT", "NET")
    return raw.lines().map { it.trim().uppercase() }
        .filter { it.startsWith(prefix) }
        .map { it.removePrefix(prefix) }
        .firstOrNull { it in known }
        ?.let { if (it == "CBL") "SAT/CBL" else it }
}

private fun parseStatus(raw: String, zone: String): String {
    val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() && it != "?" }
    if (lines.isEmpty()) return "No readable status values returned"
    val prefix = when(zone) { "Main Zone" -> "MV"; "Zone 2" -> "Z2"; else -> "Z3" }
    val volLine = lines.firstOrNull { it.startsWith(prefix) && it.length > prefix.length && it.removePrefix(prefix).firstOrNull()?.isDigit() == true }
    val vol = volLine?.removePrefix(prefix)?.let { digits -> decodeVolumeDigits(digits, zone) }?.let { db -> "${"%.1f".format(java.util.Locale.US, db)} dB" }
    val src = parseSourceCode(raw, zone)
    return listOfNotNull(vol?.let { "Volume: $it" }, src?.let { "Source: $it" }, lines.firstOrNull { it == "PWON" || it == "Z2ON" || it == "Z3ON" }?.let { "Power: On" }).joinToString("  •  ").ifBlank { lines.joinToString("  ") }
}

// Main-zone MV responses use two digits for whole steps (MV20 = -60 dB)
// and three digits for half steps (MV205 = -59.5 dB).
// Zone 2/3 replies use two digits. Do not divide every Main-zone reply by ten.
private fun decodeVolumeDigits(digits: String, zone: String): Float? {
    if (digits.isEmpty() || !digits.all(Char::isDigit)) return null
    val raw = digits.toIntOrNull() ?: return null
    val level = if (zone == "Main Zone" && digits.length == 3) raw / 10f else raw.toFloat()
    if (level < 0.5f || level > 98f) return null
    return (level - 80f).coerceIn(-79.5f, 18f)
}

private fun parseVolumeDb(raw: String, zone: String): Float? {
    val prefix = when(zone) { "Main Zone" -> "MV"; "Zone 2" -> "Z2"; else -> "Z3" }
    return raw.lines().asSequence().map { it.trim() }
        .filter { it.startsWith(prefix) }
        .mapNotNull { decodeVolumeDigits(it.removePrefix(prefix), zone) }
        .lastOrNull()
}

private fun parsePowerState(raw: String, zone: String): Boolean? {
    val prefix = when(zone) { "Main Zone" -> "PW"; "Zone 2" -> "Z2"; else -> "Z3" }
    val lines = raw.lines().map { it.trim().uppercase() }
    if (lines.any { it == "${prefix}OFF" || it == "PWSTANDBY" }) return false
    if (lines.any { it == "${prefix}ON" }) return true
    return null
}


// V0.4: locally saved speaker-distance planning screen. No undocumented receiver commands.
private val speakerLayouts = linkedMapOf(
    "2.0" to listOf("Front Left", "Front Right"),
    "5.1" to listOf("Front Left", "Front Right", "Center", "Surround Left", "Surround Right", "Subwoofer 1"),
    "7.1" to listOf("Front Left", "Front Right", "Center", "Surround Left", "Surround Right", "Surround Back Left", "Surround Back Right", "Subwoofer 1"),
    "5.1.2" to listOf("Front Left", "Front Right", "Center", "Surround Left", "Surround Right", "Front Height Left", "Front Height Right", "Subwoofer 1"),
    "7.1.4" to listOf("Front Left", "Front Right", "Center", "Surround Left", "Surround Right", "Surround Back Left", "Surround Back Right", "Front Height Left", "Front Height Right", "Rear Height Left", "Rear Height Right", "Subwoofer 1")
)

@Composable
private fun SpeakerSetupPage(controller: ReceiverController, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("speaker_distances_v1", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    var receiverReport by remember { mutableStateOf("Not connected to receiver distances yet. Local values are shown below.") }
    var receiverFrontLeft by remember { mutableStateOf<Float?>(null) }
    var receiverFrontRight by remember { mutableStateOf<Float?>(null) }
    var useFeet by remember { mutableStateOf(prefs.getBoolean("feet", true)) }
    var layout by remember { mutableStateOf(prefs.getString("layout", "5.1") ?: "5.1") }
    var layoutExpanded by remember { mutableStateOf(false) }
    val distances = remember { mutableStateMapOf<String, Float>() }
    LaunchedEffect(Unit) {
        speakerLayouts.values.flatten().distinct().forEach { name ->
            distances[name] = prefs.getFloat("distance_$name", 3.0f)
        }
    }
    Row(Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(9.dp)).padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
        DarkButton("‹ BACK", Modifier.width(112.dp)) { onBack() }
        Text("Speaker Setup", Modifier.weight(1f), color = SilverLight, fontFamily = FontFamily.Serif, fontSize = 20.sp, textAlign = TextAlign.Center)
    }
    Spacer(Modifier.height(10.dp))
    InsetPanel("DISTANCE UNITS") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(true to "Feet (ft)", false to "Meters (m)").forEach { (feet, label) ->
                ZoneTab(label, useFeet == feet, Modifier.weight(1f)) {
                    useFeet = feet
                    prefs.edit().putBoolean("feet", feet).apply()
                }
            }
        }
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("RECEIVER DISTANCES • READ ONLY") {
        DarkButton(if (refreshing) "READING RECEIVER..." else "↻  REFRESH DISTANCES", Modifier.fillMaxWidth()) {
            if (!refreshing) {
                refreshing = true
                scope.launch {
                    val result = controller.readSpeakerDistances()
                    result.onSuccess { data ->
                        receiverFrontLeft = data.first
                        receiverFrontRight = data.second
                        receiverReport = "Receiver responded: Front Left ${"%.2f".format(java.util.Locale.US, data.first)} m • Front Right ${"%.2f".format(java.util.Locale.US, data.second)} m. Read-only; local values unchanged."
                    }.onFailure { err ->
                        receiverFrontLeft = null
                        receiverFrontRight = null
                        receiverReport = "Receiver distances unavailable: ${err.message ?: "unsupported endpoint"}. Local values are unchanged."
                    }
                    refreshing = false
                }
            }
        }
        Text(receiverReport, color = if (receiverFrontLeft != null) Color(0xFF72D4FF) else Silver, fontSize = 11.sp, lineHeight = 15.sp)
        if (receiverFrontLeft != null && receiverFrontRight != null) {
            val multiplier = if (useFeet) 3.28084f else 1f
            val unit = if (useFeet) "ft" else "m"
            Text("Front Left (receiver): ${"%.2f".format(java.util.Locale.US, receiverFrontLeft!! * multiplier)} $unit", color = Blue, fontSize = 12.sp)
            Text("Front Right (receiver): ${"%.2f".format(java.util.Locale.US, receiverFrontRight!! * multiplier)} $unit", color = Blue, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("SPEAKER CONFIGURATION") {
        Box {
            DarkButton("Layout: $layout  ▾", Modifier.fillMaxWidth()) { layoutExpanded = true }
            DropdownMenu(expanded = layoutExpanded, onDismissRequest = { layoutExpanded = false }) {
                speakerLayouts.keys.forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = {
                        layout = option
                        layoutExpanded = false
                        prefs.edit().putString("layout", option).apply()
                    })
                }
            }
        }
        Text("Choose the layout matching your receiver's enabled speakers. Automatic detection is not yet available.", color = Silver, fontSize = 11.sp, lineHeight = 15.sp)
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("SPEAKER DISTANCES") {
        Text("Editable local values • separate from receiver readings", color = Color(0xFFFFD6A1), fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        speakerLayouts[layout].orEmpty().forEach { name ->
            val meters = distances[name] ?: 3f
            val shown = if (useFeet) meters * 3.28084f else meters
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(name, Modifier.weight(1f), color = Color.White, fontSize = 12.sp, lineHeight = 14.sp)
                DistanceStepButton("−") {
                    val step = if (useFeet) 0.3048f else 0.1f
                    val updated = (meters - step).coerceAtLeast(0f)
                    distances[name] = updated
                    prefs.edit().putFloat("distance_$name", updated).apply()
                }
                Text("${"%.1f".format(java.util.Locale.US, shown)}", color = Blue, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.width(49.dp))
                DistanceStepButton("+") {
                    val step = if (useFeet) 0.3048f else 0.1f
                    val updated = (meters + step).coerceAtMost(30f)
                    distances[name] = updated
                    prefs.edit().putFloat("distance_$name", updated).apply()
                }
            }
            HorizontalDivider(color = Silver.copy(alpha = 0.22f), thickness = 0.5.dp)
        }
    }
    Spacer(Modifier.height(9.dp))
    DarkButton("RESET DISTANCES TO 3.0 m", Modifier.fillMaxWidth()) {
        speakerLayouts[layout].orEmpty().forEach { name ->
            distances[name] = 3f
            prefs.edit().putFloat("distance_$name", 3f).apply()
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("Receiver Refresh is read-only. The receiver readings above are separate from locally saved editable distances. No calibration commands are sent.", color = Ink, fontSize = 11.sp, lineHeight = 15.sp, textAlign = TextAlign.Center)
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun DistanceStepButton(label: String, onClick: () -> Unit) {
    Box(Modifier.size(33.dp).clip(CircleShape)
        .background(Brush.verticalGradient(listOf(Color(0xFF555250), Ink)))
        .border(1.dp, Silver, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}


// Port discovery deliberately uses TCP connect checks only. It does not issue
// commands to unknown services or attempt authentication. Receiver-only target.
private data class PortFinding(val port: Int, val description: String)
private fun portDescription(port: Int): String = when (port) {
    23 -> "Telnet / receiver status (known control interface)"
    80 -> "HTTP (possible receiver web interface)"
    443 -> "HTTPS"
    8080 -> "HTTP receiver control (known working interface)"
    11080 -> "Experimental speaker AJAX interface (unverified)"
    1900 -> "UPnP / SSDP commonly uses UDP; TCP result not conclusive"
    5000 -> "Possible UPnP service (not verified)"
    else -> "Unidentified TCP service — open port does not prove a feature"
}

// Non-invasive identification: HTTP GET / on established web ports only;
// on all other ports, listen briefly for unsolicited banners without sending data.
private data class ServiceFinding(val port: Int, val result: String)
private suspend fun identifyService(host: String, port: Int): ServiceFinding = withContext(Dispatchers.IO) {
    val result = try {
        if (port in setOf(80, 443, 8080)) {
            val scheme = if (port == 443) "https" else "http"
            val connection = URL("$scheme://$host:$port/").openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 1800
                connection.readTimeout = 1800
                connection.instanceFollowRedirects = false
                connection.useCaches = false
                connection.requestMethod = "GET"
                val code = connection.responseCode
                val server = connection.getHeaderField("Server")?.take(90) ?: "not advertised"
                val type = connection.contentType?.take(90) ?: "not advertised"
                "$scheme response HTTP $code; Server: $server; Content-Type: $type"
            } finally { connection.disconnect() }
        } else {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1200)
                socket.soTimeout = 500
                val bytes = ByteArray(120)
                val count = try { socket.getInputStream().read(bytes) } catch (_: java.net.SocketTimeoutException) { -1 }
                if (count > 0) {
                    val banner = String(bytes, 0, count, Charsets.UTF_8)
                        .map { if (it.code in 32..126) it else ' ' }.joinToString("").trim().take(100)
                    "Passive banner: ${if (banner.isBlank()) "binary or nonprintable data" else banner}"
                } else "No unsolicited banner; protocol unknown (no commands sent)"
            }
        }
    } catch (e: Exception) { "No identifiable response: ${e.javaClass.simpleName}: ${e.message?.take(90) ?: "unknown"}" }
    ServiceFinding(port, result)
}

@Composable
private fun DiagnosticsPage(controller: ReceiverController, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var mode by remember { mutableStateOf("Quick") }
    var customPorts by remember { mutableStateOf("23, 80, 443, 8080, 11080") }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var findings by remember { mutableStateOf(listOf<PortFinding>()) }
    var outcome by remember { mutableStateOf("Not scanned. No receiver settings will be changed.") }
    var scanJob by remember { mutableStateOf<Job?>(null) }
    var identifying by remember { mutableStateOf(false) }
    var serviceResults by remember { mutableStateOf(listOf<ServiceFinding>()) }
    var identificationStatus by remember { mutableStateOf("Not identified yet.") }
    var identifyJob by remember { mutableStateOf<Job?>(null) }
    val knownPorts = listOf(23, 80, 443, 8080, 11080)
    val previousOpenPorts = listOf(23,80,443,1255,1256,3100,3101,7000,8015,8080,10080,10101,10234,10443,10555,36670,40031,47938,51321,60006,60080)
    fun stop() { scanJob?.cancel(); scanJob = null; running = false; outcome = "Scan stopped. Partial results retained."
        identifyJob?.cancel(); identifyJob = null; identifying = false }
    DisposableEffect(Unit) { onDispose { scanJob?.cancel(); identifyJob?.cancel() } }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        DarkButton("‹ BACK", Modifier.width(105.dp)) { stop(); onBack() }
        Text("Receiver Diagnostics", Modifier.weight(1f), color = Ink, fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold, fontSize = 19.sp, textAlign = TextAlign.Center)
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("TCP PORT DISCOVERY") {
        Text("Receiver: ${controller.host}", color = SilverLight, fontSize = 13.sp)
        Text("Read-only connection checks. An open port does not identify its function.", color = Silver, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("Quick", "Extended", "Custom").forEach { item ->
                ZoneTab(item, mode == item, Modifier.weight(1f)) { if (!running) mode = item }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(when(mode) {
            "Quick" -> "Known receiver ports: ${knownPorts.joinToString()}"
            "Extended" -> "All TCP ports (1–65535). Can take several minutes; stop any time."
            else -> "Enter TCP ports or ranges (example: 23,80,8000-8100). Maximum 65535."
        }, color = Silver, fontSize = 12.sp)
        if (mode == "Custom") {
            OutlinedTextField(value = customPorts, onValueChange = { customPorts = it.take(300) },
                label = { Text("Ports and ranges") }, singleLine = false, maxLines = 3,
                modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
        if (!running) {
            DarkButton("▶  START ${mode.uppercase()} SCAN", Modifier.fillMaxWidth()) {
                val ports = try {
                    when(mode) {
                        "Quick" -> knownPorts
                        "Extended" -> (1..65535).toList()
                        else -> customPorts.split(',').flatMap { token ->
                            val t = token.trim()
                            if (t.contains('-')) {
                                val parts = t.split('-').map { it.trim().toInt() }
                                require(parts.size == 2 && parts[0] in 1..65535 && parts[1] in parts[0]..65535)
                                (parts[0]..parts[1]).toList()
                            } else listOf(t.toInt().also { require(it in 1..65535) })
                        }
                    }.distinct().sorted()
                } catch (_: Exception) { emptyList() }
                if (ports.isEmpty()) outcome = "Invalid port list. Use 1–65535 or ranges such as 8000-8100."
                else {
                    findings = emptyList(); serviceResults = emptyList(); completed = 0; total = ports.size; running = true
                    outcome = "Checking TCP ports on ${controller.host}…"
                    val address = controller.host.trim()
                    scanJob = scope.launch {
                        try {
                            val limiter = Semaphore(64)
                            // Batches keep UI responsive and bound memory consumption.
                            for (batch in ports.chunked(256)) {
                                val results = withContext(Dispatchers.IO) {
                                    batch.map { port -> async {
                                        limiter.withPermit {
                                            ensureActive()
                                            val open = try {
                                                Socket().use { socket -> socket.connect(InetSocketAddress(address, port), if (mode == "Quick") 900 else 350); true }
                                            } catch (_: Exception) { false }
                                            if (open) PortFinding(port, portDescription(port)) else null
                                        }
                                    } }.awaitAll().filterNotNull()
                                }
                                findings = (findings + results).sortedBy { it.port }
                                completed += batch.size
                            }
                            outcome = "Scan complete: ${findings.size} open TCP ports of $total checked. Services are tentative until verified."
                        } catch (_: CancellationException) {
                            outcome = "Scan stopped after $completed of $total ports."
                        } catch (e: Exception) {
                            outcome = "Scan failed: ${e.message ?: e.javaClass.simpleName}"
                        } finally { running = false; scanJob = null }
                    }
                }
            }
        } else DarkButton("■  STOP SCAN", Modifier.fillMaxWidth()) { stop() }
        Spacer(Modifier.height(8.dp))
        Text(outcome, color = SilverLight, fontSize = 12.sp)
        if (total > 0) {
            LinearProgressIndicator(progress = { completed.toFloat() / total }, modifier = Modifier.fillMaxWidth(), color = Blue)
            Text("$completed / $total ports checked", color = Silver, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("DISCOVERED SERVICES") {
        if (findings.isEmpty()) Text("No open TCP ports identified yet.", color = Silver)
        findings.forEach { item ->
            Text("TCP ${item.port}  •  OPEN", color = Blue, fontWeight = FontWeight.Bold)
            Text(item.description, color = SilverLight, fontSize = 12.sp)
            Spacer(Modifier.height(5.dp))
        }
        Spacer(Modifier.height(7.dp))
        DarkButton("COPY DIAGNOSTIC REPORT", Modifier.fillMaxWidth()) {
            val report = buildString {
                appendLine("Silvertone Hi-Fi v0.7 — Receiver TCP Diagnostics")
                appendLine("Receiver: ${controller.host}")
                appendLine("Mode: $mode; checked: $completed/$total")
                appendLine(outcome)
                findings.forEach { appendLine("TCP ${it.port}: OPEN — ${it.description}") }
                appendLine("Only TCP connect checks performed. No receiver settings changed.")
            }
            clipboard.setText(AnnotatedString(report))
        }
    }
    Spacer(Modifier.height(9.dp))
    InsetPanel("SERVICE IDENTIFICATION — EXPERIMENTAL") {
        Text("Uses the 21 ports from your SR7013 scan, or the most recent scan results. Only established HTTP ports receive GET /; other services are listened to passively.", color = Silver, fontSize = 12.sp)
        Spacer(Modifier.height(7.dp))
        if (!identifying && !running) {
            DarkButton("IDENTIFY DISCOVERED SERVICES", Modifier.fillMaxWidth()) {
                val ports = if (findings.isNotEmpty()) findings.map { it.port } else previousOpenPorts
                identifying = true; serviceResults = emptyList()
                identificationStatus = "Checking ${ports.size} services on ${controller.host}…"
                identifyJob = scope.launch {
                    try {
                        for (port in ports) {
                            ensureActive()
                            val finding = identifyService(controller.host.trim(), port)
                            serviceResults = serviceResults + finding
                            identificationStatus = "Identified ${serviceResults.size}/${ports.size} services."
                        }
                        identificationStatus = "Identification complete. Protocols remain tentative."
                    } catch (_: CancellationException) {
                        identificationStatus = "Identification stopped; partial results retained."
                    } finally { identifying = false; identifyJob = null }
                }
            }
        } else if (identifying) DarkButton("STOP IDENTIFICATION", Modifier.fillMaxWidth()) {
            identifyJob?.cancel(); identifying = false
        }
        Text(identificationStatus, color = SilverLight, fontSize = 12.sp)
        serviceResults.forEach { item ->
            Text("TCP ${item.port}", color = Blue, fontWeight = FontWeight.Bold)
            Text(item.result, color = SilverLight, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.height(6.dp))
        DarkButton("COPY SERVICE REPORT", Modifier.fillMaxWidth()) {
            val report = buildString {
                appendLine("Silvertone Hi-Fi v0.7 — Receiver Service Identification")
                appendLine("Receiver: ${controller.host}")
                appendLine(identificationStatus)
                serviceResults.forEach { appendLine("TCP ${it.port}: ${it.result}") }
                appendLine("Read-only discovery. No settings modified. Open ports do not establish speaker distance support.")
            }
            clipboard.setText(AnnotatedString(report))
        }
    }
    Spacer(Modifier.height(9.dp))
    Text("TCP scanning cannot detect UDP-only services or prove which commands a service supports. No settings are written.",
        color = Ink, fontSize = 12.sp, textAlign = TextAlign.Center)
}
