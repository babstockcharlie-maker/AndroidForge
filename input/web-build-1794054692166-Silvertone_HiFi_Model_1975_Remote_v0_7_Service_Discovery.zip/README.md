# Silvertone Hi-Fi Model 1975 Remote — v0.7

AndroidForge/Android Studio source project.

## New: Service Identification
The Receiver Diagnostics page now offers **Identify Discovered Services** after a TCP scan, or uses the 21 open TCP ports from the user's SR7013 scan. Known HTTP ports 80, 443 and 8080 receive only an HTTP GET to `/` to collect status and headers. Other ports are connected to briefly and listened to for unsolicited banners; no protocol commands are transmitted. The feature shows per-port outcomes and supports Copy Service Report.

No authentication, settings changes, or speaker calibration writes. A responsive service does not establish speaker-distance readback.

All v0.6 controls and UI are retained. Not compiled or receiver-tested.
