# Marantz SR7013 Remote — Version 5.4
## 1060B Walnut & Brushed Aluminium Edition

This is an Android Studio / AndroidForge source project ZIP, not a prebuilt APK.

### Visual redesign
- Walnut-coloured side rails and a brushed-aluminium-style faceplate
- Dark recessed-style status and control panels
- Blue illuminated zone selection and accent controls
- Large touch-friendly power, mute and volume buttons
- Large volume slider, source selector, tone controls and sound modes
- Footer inscription: “Inspired by Marantz 1060B · Est. 1975”
- Receiver IP settings are tucked behind the gear icon to reduce everyday clutter

### Receiver connection
- Receiver IP defaults to `192.168.0.3` and can be changed under the gear icon.
- HTTP direct commands use port 8080.
- Live status uses TCP port 23.

### JBL Deck / Zone 2
- Zone 2 power, mute and volume up/down retain their direct-command controls.
- The source selector uses Zone 2-prefixed source commands, including `Z2NET` for HEOS/network.
- The absolute-volume slider sends a two-digit Zone 2 value, while Main Zone retains its three-digit tenths format.
- “Start Outdoor Music” powers Zone 2 and then explicitly sends either the Main Zone source or the separately selected JBL Deck source. It no longer deliberately leaves source selection to the receiver's remembered Zone 2 input.

IMPORTANT: Denon/Marantz direct-command acknowledgements over HTTP do not prove that the receiver applied a setting. Confirm source and slider behavior on the SR7013 after installation. The Zone 2 absolute-volume format is implemented separately from Main Zone and should be verified against the receiver's live response. If an input is not available for Zone 2 on the receiver, it may reject or ignore that source command.

### Existing functions
- Main Zone and Zone 3 remain available.
- Main Zone bass/treble controls and sound-mode buttons are retained.
- Outdoor Music shortcut remains available in the JBL Deck view.

Do not expose receiver control ports to the public internet. Keep the phone and receiver on the trusted local network.


Version 5.4.1 build fix: explicitly returns Unit from the HTTP command block so ReceiverController.command satisfies Result<Unit>.
