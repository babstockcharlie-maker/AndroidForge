package com.subtune.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.View
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val frequencies = (25..90 step 1).toList()
    private val results = mutableListOf<Result>()
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var mode: Spinner
    private lateinit var position: Spinner
    private lateinit var freq: SeekBar
    private lateinit var freqLabel: TextView
    private lateinit var amplitude: SeekBar
    private lateinit var amplitudeLabel: TextView
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private var tone: AudioTrack? = null
    private val targetHz = AtomicInteger(40)
    private val toneEnabled = AtomicBoolean(false)
    private var toneWriter: Thread? = null
    private var recorder: AudioRecord? = null
    private var amplitudeFraction = 0.06
    private val sampleRate = 44100

    data class Result(val location:String, val hz:Int, val db:Double, val rmsDb:Double, val timestamp:String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,22,24,12); setBackgroundColor(Color.rgb(247,248,250)) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        fun heading(s:String, size:Float=18f): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.rgb(20,35,50)); setPadding(0,8,0,8); root.addView(this) }
        heading("SubTune", 30f)
        heading("MillWattone • Subwoofer tuning measurement", 14f)
        heading("Test location")
        position = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Calibration", "Port", "Cone")); root.addView(this) }
        heading("Test mode")
        heading("Fine sweep: 25–90 Hz in 1 Hz steps. Continuous, click-reduced tones.",13f)
        mode = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Automatic sweep", "Manual frequency")); root.addView(this) }
        freqLabel = heading("Manual frequency: 40 Hz",16f)
        freq = SeekBar(this).apply { max=70; progress=20; root.addView(this); setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){freqLabel.text="Manual frequency: ${20+p} Hz"}
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
        }) }
        amplitudeLabel = heading("Digital tone amplitude: 6% (start with amplifier low)", 15f)
        amplitude = SeekBar(this).apply { max=19; progress=5; root.addView(this); setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){amplitudeFraction=(p+1)/100.0; amplitudeLabel.text="Digital tone amplitude: ${p+1}% (start with amplifier low)"}
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
        }) }
        heading("Keep phone and amplifier volumes unchanged between Port and Cone tests. Position microphone ~1 inch from opening/cone. Stop for excessive excursion.",13f)
        runButton=Button(this).apply { text="RUN SELECTED TEST"; root.addView(this); setOnClickListener { begin() } }
        stopButton=Button(this).apply { text="STOP AUDIO / TEST"; isEnabled=false; root.addView(this); setOnClickListener { running.set(false); toneEnabled.set(false) } }
        Button(this).apply { text="SHARE CSV RESULTS"; root.addView(this); setOnClickListener { shareCsv() } }
        Button(this).apply { text="CLEAR RESULTS"; root.addView(this); setOnClickListener { if(!running.get()){results.clear();output.text="No measurements yet."} } }
        status=heading("Ready. Connect Bluetooth media output and grant microphone permission.",14f)
        output=heading("No measurements yet.",14f)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10)
    }

    private fun begin() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10);return}
        if(!running.compareAndSet(false,true))return
        val loc=position.selectedItem.toString()
        val chosen=if(loc=="Calibration") listOf(50) else if(mode.selectedItemPosition==0) frequencies else listOf(freq.progress+20)
        runButton.isEnabled=false;stopButton.isEnabled=true
        thread(name="SubTuneMeasurement") {
            try {
                report("Starting in 5 seconds. Check low volume and microphone placement.")
                for(i in 5 downTo 1){if(!running.get())break; report("Starting in $i…");Thread.sleep(1000)}
                if(running.get()) {
                    if(loc=="Calibration") {
                        report("Calibration: silence/background at 50 Hz (3 seconds)")
                        val bg=measureOnly(50,3000)
                        if(running.get()) {
                            report("Calibration: playing 50 Hz")
                            val sig=playAndMeasure(50)
                            if(sig!=null){report("Calibration 50 Hz: background ${fmt(bg.first)} dBFS, tone ${fmt(sig.first)} dBFS, difference ${fmt(sig.first-bg.first)} dB (relative only). Check for clean sound.")}
                        }
                    } else {
                        startContinuousTone(chosen.first())
                        try {
                            for(hz in chosen) {
                                if(!running.get())break
                                report("$loc: measuring $hz Hz (${chosen.indexOf(hz)+1}/${chosen.size})")
                                targetHz.set(hz)
                                // Frequency glides over ~100 ms; allow Bluetooth and speaker response to settle.
                                Thread.sleep(450)
                                val reading=if(running.get()) measureOnly(hz,900) else null
                                if(reading!=null && running.get()) {
                                    val result=Result(loc,hz,reading.first,reading.second,SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date()))
                                    synchronized(results){results.add(result)}
                                    main.post { updateOutput() }
                                }
                            }
                        } finally { stopContinuousTone() }
                        if(running.get()) report("$loc complete. Review results or measure the other location at the SAME gain.")
                    }
                }
            } catch(e:Exception){report("Test error: ${e.message ?: e.javaClass.simpleName}")}
            finally {running.set(false);releaseAudio();main.post {runButton.isEnabled=true;stopButton.isEnabled=false} }
        }
    }

    // A single AudioTrack stays open throughout the sweep, preserving phase continuity.
    // A short frequency glide and gain envelope prevent hard discontinuities/clicks.
    private fun startContinuousTone(initialHz:Int) {
        val minBytes=AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0)throw IllegalStateException("Audio output unavailable")
        val player=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(max(minBytes,8192)).build()
        tone=player
        targetHz.set(initialHz)
        toneEnabled.set(true)
        toneWriter=thread(name="SubTuneContinuousTone") {
            var phase=0.0
            var currentHz=initialHz.toDouble()
            var gain=0.0
            val data=ShortArray(2048)
            try {
                player.play()
                while(running.get() && toneEnabled.get()) {
                    for(i in data.indices step 2) {
                        val desired=targetHz.get().toDouble()
                        currentHz+=(desired-currentHz)/ (sampleRate*0.10)
                        gain+=(1.0-gain)/(sampleRate*0.03)
                        val sample=(sin(phase)*amplitudeFraction*gain*32767.0).roundToInt().coerceIn(-32767,32767).toShort()
                        data[i]=sample;data[i+1]=sample
                        phase+=2.0*PI*currentHz/sampleRate
                        if(phase>=2.0*PI)phase-=2.0*PI
                    }
                    val wrote=player.write(data,0,data.size,AudioTrack.WRITE_BLOCKING)
                    if(wrote<0)break
                }
                // Fade out instead of abruptly stopping the output waveform.
                for(k in 0 until 5) {
                    for(i in data.indices step 2) {
                        gain*=0.998
                        val sample=(sin(phase)*amplitudeFraction*gain*32767.0).roundToInt().toShort()
                        data[i]=sample;data[i+1]=sample
                        phase+=2.0*PI*currentHz/sampleRate
                        if(phase>=2.0*PI)phase-=2.0*PI
                    }
                    if(player.write(data,0,data.size,AudioTrack.WRITE_BLOCKING)<0)break
                }
            } catch(_:Exception) {} 
        }
    }

    private fun stopContinuousTone() {
        toneEnabled.set(false)
        try { toneWriter?.join(700) } catch(_:InterruptedException) { Thread.currentThread().interrupt() }
        toneWriter=null
        val player=tone
        tone=null
        try { player?.pause();player?.flush();player?.release() } catch(_:Exception) {}
    }

    private fun playAndMeasure(hz:Int):Pair<Double,Double>? {
        startContinuousTone(hz)
        return try {
            Thread.sleep(1200)
            if(running.get())measureOnly(hz,2200) else null
        } finally { stopContinuousTone() }
    }

    private fun measureOnly(hz:Int,durationMs:Int):Pair<Double,Double> {
        val source=if(Build.VERSION.SDK_INT>=24 && (getSystemService(AUDIO_SERVICE) as AudioManager).getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED)=="true") MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val min=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(min<=0)throw IllegalStateException("Microphone recording unavailable")
        val mic=AudioRecord(source,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,max(min,8192))
        recorder=mic
        if(mic.state!=AudioRecord.STATE_INITIALIZED){mic.release();throw IllegalStateException("Cannot initialize microphone")}
        val audioManager=getSystemService(AUDIO_SERVICE) as AudioManager
        audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.type==AudioDeviceInfo.TYPE_BUILTIN_MIC }?.let { mic.setPreferredDevice(it) }
        val block=ShortArray(2048)
        var n=0L;var sum=0.0;var re=0.0;var im=0.0
        val step=2*PI*hz/sampleRate
        try {
            mic.startRecording()
            val deadline=System.nanoTime()+durationMs*1_000_000L
            while(running.get() && System.nanoTime()<deadline) {
                val count=mic.read(block,0,block.size,AudioRecord.READ_BLOCKING)
                if(count<0)throw IllegalStateException("Mic read error $count")
                for(i in 0 until count) {
                    val x=block[i].toDouble()/32768.0
                    val a=step*n
                    re+=x*cos(a);im+=x*sin(a);sum+=x*x;n++
                }
            }
        } finally {try{mic.stop()}catch(_:Exception){};mic.release();recorder=null}
        if(n==0L)return Pair(-120.0,-120.0)
        val peak=sqrt(re*re+im*im)*2/n
        val rms=sqrt(sum/n)
        return Pair(20*log10(max(peak,1e-6)),20*log10(max(rms,1e-6)))
    }

    private fun report(s:String){main.post{status.text=s}}
    private fun fmt(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun updateOutput(){
        val snapshot=synchronized(results){results.toList()}
        val sb=StringBuilder()
        for(loc in listOf("Port","Cone")){
            val items=snapshot.filter{it.location==loc}
            if(items.isNotEmpty()){
                sb.append("\n$loc readings (relative dBFS)\n")
                for(r in items)sb.append("${r.hz} Hz: ${fmt(r.db)} dBFS\n")
            }
        }
        val port=snapshot.filter{it.location=="Port" && it.hz in 30..55}.groupBy{it.hz}.mapValues{it.value.last().db}
        val cone=snapshot.filter{it.location=="Cone" && it.hz in 30..55}.groupBy{it.hz}.mapValues{it.value.last().db}
        if(port.size>=4 && cone.size>=4){
            val peak=port.maxByOrNull{it.value}?.key
            val dip=cone.minByOrNull{it.value}?.key
            sb.append("\nPreliminary clues: port peak ${peak ?: "?"} Hz; cone minimum ${dip ?: "?"} Hz. Not calibrated; compare with visible cone movement.\n")
        }
        output.text=sb.toString().ifBlank { "No measurements yet." }
    }
    private fun shareCsv(){
        if(running.get()){Toast.makeText(this,"Stop test before exporting",Toast.LENGTH_SHORT).show();return}
        val snapshot=synchronized(results){results.toList()}
        if(snapshot.isEmpty()){Toast.makeText(this,"No measurements to export",Toast.LENGTH_SHORT).show();return}
        val csv=buildString {
            append("location,frequency_hz,tone_dbfs,rms_dbfs,timestamp\n")
            snapshot.forEach{append("${it.location},${it.hz},${fmt(it.db)},${fmt(it.rmsDb)},${it.timestamp}\n")}
        }
        // Share text avoids needing FileProvider and works on current Android versions.
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"SubTune measurements.csv");putExtra(Intent.EXTRA_TEXT,csv)},"Share SubTune CSV"))
    }
    private fun releaseAudio(){stopContinuousTone();try{recorder?.stop();recorder?.release()}catch(_:Exception){};recorder=null}
    override fun onDestroy(){running.set(false);toneEnabled.set(false);super.onDestroy()}
}


