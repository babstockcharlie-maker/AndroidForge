Marantz Remote V6.2 — Script Graphic and Tone Label

Based on personal V6.1. Replaces Android cursive font subtitle with a transparent graphic extracted from the approved concept render, including decorative horizontal lines. Changes BASS / TREBLE panel heading to TONE while retaining Bass and Treble slider labels. All receiver controls, networking, and other styling unchanged.

This is a source project for AndroidForge, not a precompiled APK. Build and test on device. Commercial Silvertone project is untouched.
