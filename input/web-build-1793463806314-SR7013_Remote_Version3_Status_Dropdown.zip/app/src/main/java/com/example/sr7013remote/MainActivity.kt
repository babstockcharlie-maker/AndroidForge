package com.example.sr7013remote

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.Socket
import java.io.BufferedInputStream
import java.io.OutputStream
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RemoteScreen() } }
    }
}

private class ReceiverController(context: Context) {
    private val prefs = context.getSharedPreferences("receiver", Context.MODE_PRIVATE)
    var host: String
        get() = prefs.getString("host", "") ?: ""
        set(value) { prefs.edit().putString("host", value.trim()).apply() }

    // Denon/Marantz AVR direct-command endpoint. Verify command availability on SR7013 firmware.
    suspend fun command(command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val encodedCommand = URLEncoder.encode(command, StandardCharsets.UTF_8.name()).replace("+", "%20")
            val url = URL("http://$address:8080/goform/formiPhoneAppDirect.xml?$encodedCommand")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2500
                readTimeout = 2500
                useCaches = false
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Receiver returned HTTP $code")
                connection.inputStream.use { it.readBytes() }
                Unit
            } finally { connection.disconnect() }
        }
    }

    // Read live status over the receiver's standard Denon/Marantz TCP control protocol (port 23).
    // This is separate from the HTTP port 8080 used for button commands.
    suspend fun readStatus(zone: String): Result<String> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val queries = when (zone) {
                "Main Zone" -> listOf("PW?", "MV?", "MU?", "SI?", "MS?")
                "JBL Deck" -> listOf("Z2?", "Z2MU?")
                else -> listOf("Z3?", "Z3MU?")
            }
            val socket = Socket()
            try {
                socket.connect(java.net.InetSocketAddress(address, 23), 1800)
                socket.soTimeout = 900
                val output: OutputStream = socket.getOutputStream()
                val input = BufferedInputStream(socket.getInputStream())
                val lines = mutableListOf<String>()
                for (query in queries) {
                    output.write((query + "\r").toByteArray(StandardCharsets.US_ASCII))
                    output.flush()
                    val deadline = System.currentTimeMillis() + 450
                    val response = StringBuilder()
                    while (System.currentTimeMillis() < deadline) {
                        try {
                            val b = input.read()
                            if (b < 0) break
                            if (b == 13 || b == 10) {
                                if (response.isNotEmpty()) { lines.add(response.toString()); response.setLength(0) }
                            } else if (b in 32..126) response.append(b.toChar())
                        } catch (_: java.net.SocketTimeoutException) { break }
                    }
                    if (response.isNotEmpty()) lines.add(response.toString())
                }
                if (lines.isEmpty()) throw IllegalStateException("No status reply received on TCP port 23. Check the receiver's Network Control setting.")
                lines.distinct().joinToString("\n")
            } finally { socket.close() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteScreen() {
    val context = LocalContext.current
    val controller = remember { ReceiverController(context) }
    var ip by remember { mutableStateOf(controller.host) }
    var message by remember { mutableStateOf("Enter your SR7013 IP address, then tap Save & Test.") }
    var busy by remember { mutableStateOf(false) }
    var inputExpanded by remember { mutableStateOf(false) }
    var mainInputExpanded by remember { mutableStateOf(false) }
    var zone2InputExpanded by remember { mutableStateOf(false) }
    var zone3InputExpanded by remember { mutableStateOf(false) }
    var outdoorModeExpanded by remember { mutableStateOf(false) }
    var zonePickerExpanded by remember { mutableStateOf(false) }
    var selectedZone by remember { mutableStateOf("Main Zone") }
    var statusText by remember { mutableStateOf("Tap Refresh Status to read the receiver’s current state.") }
    var statusBusy by remember { mutableStateOf(false) }
    var selectedMainInput by remember { mutableStateOf("CBL/SAT" to "SICBL") }
    var selectedZone2Input by remember { mutableStateOf("HEOS" to "Z2HEOS") }
    var selectedZone3Input by remember { mutableStateOf("CBL/SAT" to "Z3SAT/CBL") }
    var outdoorMode by remember { mutableStateOf("Follow Main Zone") }
    val inputs = listOf(
        "CBL/SAT" to "SICBL", "Blu-ray" to "SIBD", "Game" to "SIGAME",
        "Media Player" to "SIMPLAY", "TV Audio" to "SITV", "AUX1" to "SIAUX1",
        "Bluetooth" to "SIBT", "HEOS" to "SIHEOS"
    )
    val scope = rememberCoroutineScope()

    fun send(command: String, label: String = command) {
        scope.launch {
            busy = true
            message = "Sending $label…"
            val result = controller.command(command)
            message = result.fold({ "$label command sent. Receiver response confirmed at HTTP level; state has not yet been read back." },
                { "Could not send $label: ${it.message ?: "connection error"}" })
            busy = false
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("SR7013 Remote", fontWeight = FontWeight.Bold) })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("MARANTZ • LOCAL NETWORK", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(
                value = ip, onValueChange = { ip = it },
                label = { Text("Receiver IP address") },
                placeholder = { Text("e.g. 192.168.1.50") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                controller.host = ip
                send("PW?", "Connection test (port 8080)")
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else "Save & Test")
            }
            Text(message, style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("SELECT ZONE", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(expanded = zonePickerExpanded, onExpandedChange = { zonePickerExpanded = it }) {
                OutlinedTextField(
                    value = selectedZone, onValueChange = {}, readOnly = true,
                    label = { Text("Zone controls") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = zonePickerExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = zonePickerExpanded, onDismissRequest = { zonePickerExpanded = false }) {
                    listOf("Main Zone", "JBL Deck", "Zone 3").forEach { zone ->
                        DropdownMenuItem(text = { Text(zone) }, onClick = { selectedZone = zone; zonePickerExpanded = false })
                    }
                }
            }
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LIVE RECEIVER STATUS • $selectedZone", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(statusText, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        scope.launch {
                            statusBusy = true
                            statusText = "Reading current state from receiver…"
                            val result = controller.readStatus(selectedZone)
                            statusText = result.fold({ parseStatus(it, selectedZone) }, { "Status unavailable: ${it.message ?: "connection failed"}" })
                            statusBusy = false
                        }
                    }, enabled = !statusBusy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (statusBusy) "Reading…" else "↻ Refresh Status")
                    }
                }
            }

            if (selectedZone == "Main Zone") {
            HorizontalDivider()
            Text("POWER & VOLUME", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("PWON", "Power on") }
                RemoteButton("Standby", Modifier.weight(1f)) { send("PWSTANDBY", "Standby") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("MVDOWN", "Volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("MUON", "Mute on") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("MVUP", "Volume up") }
            }
            RemoteButton("Unmute", Modifier.fillMaxWidth()) { send("MUOFF", "Unmute") }

            HorizontalDivider()
            Text("INPUTS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(expanded = inputExpanded, onExpandedChange = { inputExpanded = it }) {
                OutlinedTextField(
                    value = "Choose input", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = inputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = inputExpanded, onDismissRequest = { inputExpanded = false }) {
                    inputs.forEach { (label, cmd) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            inputExpanded = false
                            selectedMainInput = label to cmd
                            send(cmd, "Input: $label")
                        })
                    }
                }
            }

            HorizontalDivider()
            Text("SOUND MODES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            listOf(
                "Auto" to "MSAUTO", "Stereo" to "MSSTEREO", "Direct" to "MSDIRECT",
                "Pure Direct" to "MSPURE DIRECT", "Dolby Surround" to "MSDOLBY SURROUND",
                "DTS Neural:X" to "MSDTS NEURAL:X"
            ).forEach { (label, cmd) ->
                RemoteButton(label, Modifier.fillMaxWidth()) { send(cmd, "Sound mode: $label") }
            }

            }

            if (selectedZone == "JBL Deck") {
            HorizontalDivider()
            Text("ZONE 2 • JBL DECK", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("Outdoor speakers", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("Z2ON", "JBL Deck power on") }
                RemoteButton("Off", Modifier.weight(1f)) { send("Z2OFF", "JBL Deck power off") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("Z2DOWN", "JBL Deck volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("Z2MUON", "JBL Deck mute") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("Z2UP", "JBL Deck volume up") }
            }
            RemoteButton("Unmute JBL Deck", Modifier.fillMaxWidth()) { send("Z2MUOFF", "JBL Deck unmute") }
            ExposedDropdownMenuBox(expanded = zone2InputExpanded, onExpandedChange = { zone2InputExpanded = it }) {
                OutlinedTextField(
                    value = "JBL Deck source: ${selectedZone2Input.first}", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = zone2InputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = zone2InputExpanded, onDismissRequest = { zone2InputExpanded = false }) {
                    inputs.forEach { (label, mainCmd) ->
                        val zoneCmd = when (mainCmd) {
                            "SICBL" -> "Z2SAT/CBL"
                            "SIBD" -> "Z2BD"
                            "SIGAME" -> "Z2GAME"
                            "SIMPLAY" -> "Z2MPLAY"
                            "SITV" -> "Z2TV"
                            "SIAUX1" -> "Z2AUX1"
                            "SIBT" -> "Z2BT"
                            else -> "Z2HEOS"
                        }
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            zone2InputExpanded = false
                            selectedZone2Input = label to zoneCmd
                            send(zoneCmd, "JBL Deck source: $label")
                        })
                    }
                }
            }

            }

            if (selectedZone == "Zone 3") {
            HorizontalDivider()
            Text("ZONE 3", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("Z3ON", "Zone 3 power on") }
                RemoteButton("Off", Modifier.weight(1f)) { send("Z3OFF", "Zone 3 power off") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("Z3DOWN", "Zone 3 volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("Z3MUON", "Zone 3 mute") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("Z3UP", "Zone 3 volume up") }
            }
            RemoteButton("Unmute Zone 3", Modifier.fillMaxWidth()) { send("Z3MUOFF", "Zone 3 unmute") }
            ExposedDropdownMenuBox(expanded = zone3InputExpanded, onExpandedChange = { zone3InputExpanded = it }) {
                OutlinedTextField(
                    value = "Zone 3 source: ${selectedZone3Input.first}", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = zone3InputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = zone3InputExpanded, onDismissRequest = { zone3InputExpanded = false }) {
                    inputs.forEach { (label, mainCmd) ->
                        val zoneCmd = when (mainCmd) {
                            "SICBL" -> "Z3SAT/CBL"
                            "SIBD" -> "Z3BD"
                            "SIGAME" -> "Z3GAME"
                            "SIMPLAY" -> "Z3MPLAY"
                            "SITV" -> "Z3TV"
                            "SIAUX1" -> "Z3AUX1"
                            "SIBT" -> "Z3BT"
                            else -> "Z3HEOS"
                        }
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            zone3InputExpanded = false
                            selectedZone3Input = label to zoneCmd
                            send(zoneCmd, "Zone 3 source: $label")
                        })
                    }
                }
            }

            }

            HorizontalDivider()
            Text("OUTDOOR MUSIC", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("One-tap JBL Deck shortcut", style = MaterialTheme.typography.bodySmall)
            ExposedDropdownMenuBox(expanded = outdoorModeExpanded, onExpandedChange = { outdoorModeExpanded = it }) {
                OutlinedTextField(
                    value = outdoorMode, onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = outdoorModeExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = outdoorModeExpanded, onDismissRequest = { outdoorModeExpanded = false }) {
                    listOf("Follow Main Zone", "Use JBL Deck source").forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = {
                            outdoorMode = option
                            outdoorModeExpanded = false
                        })
                    }
                }
            }
            Button(onClick = {
                scope.launch {
                    busy = true
                    message = "Starting Outdoor Music…"
                    val powerResult = controller.command("Z2ON")
                    val sourceResult = if (outdoorMode == "Follow Main Zone") {
                        val zoneCmd = selectedMainInput.second.replaceFirst("SI", "Z2")
                            .let { if (it == "Z2CBL") "Z2SAT/CBL" else if (it == "Z2BD") "Z2BD" else it }
                        controller.command(zoneCmd)
                    } else {
                        controller.command(selectedZone2Input.second)
                    }
                    message = if (powerResult.isSuccess && sourceResult.isSuccess) {
                        "Outdoor Music commands sent to JBL Deck. Receiver state has not been read back."
                    } else {
                        "Outdoor Music could not complete: " +
                            (powerResult.exceptionOrNull()?.message ?: sourceResult.exceptionOrNull()?.message ?: "receiver command failed")
                    }
                    busy = false
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else "▶ Start Outdoor Music")
            }

            HorizontalDivider()
            Text("IMPORTANT", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
                "Buttons use the receiver's local HTTP direct-command interface on port 8080. Live status uses the standard TCP control protocol on port 23. " +
                "If status cannot be read, check the receiver's Network Control setting and ensure it allows control while powered on. " +
                "Zone status fields depend on the receiver's reply format. Do not expose receiver control ports to the public internet.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun parseStatus(raw: String, zone: String): String {
    val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() && it != "?" }
    if (lines.isEmpty()) return "No readable status values returned."
    fun value(prefix: String): String? = lines.firstOrNull { it.startsWith(prefix) && it.length > prefix.length }?.removePrefix(prefix)?.trim()
    val power = when {
        lines.any { it == "PWON" || it == "Z2ON" || it == "Z3ON" || it == "ZMON" } -> "On"
        lines.any { it == "PWSTANDBY" || it == "Z2OFF" || it == "Z3OFF" || it == "ZMOFF" } -> "Standby / Off"
        else -> null
    }
    val fields = mutableListOf<String>()
    power?.let { fields.add("Power: $it") }
    if (zone == "Main Zone") {
        value("MV")?.let { v -> fields.add("Volume: " + if (v.length >= 2 && v.all(Char::isDigit)) "${v.toInt() / 10}.${v.takeLast(1)}" else v) }
        value("MU")?.let { fields.add("Mute: ${if (it == "ON") "On" else "Off"}") }
        value("SI")?.let { fields.add("Input: $it") }
        value("MS")?.let { fields.add("Sound mode: $it") }
    } else {
        val volPrefix = if (zone == "JBL Deck") "Z2" else "Z3"
        value("${volPrefix}MU")?.let { fields.add("Mute: ${if (it == "ON") "On" else "Off"}") }
        lines.firstOrNull { it.startsWith(volPrefix) && it.length > volPrefix.length && it.removePrefix(volPrefix).firstOrNull()?.isDigit() == true }
            ?.let { fields.add("Volume: ${it.removePrefix(volPrefix)}") }
        lines.firstOrNull { it.startsWith(volPrefix) && it !in listOf("${volPrefix}ON", "${volPrefix}OFF") && it.removePrefix(volPrefix).firstOrNull()?.isLetter() == true && !it.startsWith("${volPrefix}MU") }
            ?.let { fields.add("Source: ${it.removePrefix(volPrefix)}") }
    }
    return if (fields.isEmpty()) "Receiver replied, but its status format was not recognized. Raw: ${lines.joinToString(" ")}" else fields.joinToString("\n")
}

@Composable
private fun RemoteButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 48.dp)) {
        Text(label)
    }
}
