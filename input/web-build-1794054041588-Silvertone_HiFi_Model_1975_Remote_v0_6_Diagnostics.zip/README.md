# Silvertone Hi-Fi — Model 1975 Remote v0.6

AndroidForge / Android Studio source project.

New Receiver Diagnostics page accessible from the main remote. Quick scan checks TCP 23, 80, 443, 5000, 8080 and 11080. Extended scans TCP 1–65535 in bounded batches; Custom supports comma-separated ports and ranges. Includes stop, progress, tentative descriptions, and Copy Diagnostic Report.

Safety: TCP connect-only checks; no commands are sent to unknown services, no receiver configuration is modified. Open ports cannot identify individual features. TCP scans do not detect UDP-only services. Extended scans may take minutes and can be interrupted. Only scan your own receiver.

Existing Silvertone UI, speaker-distance local storage, experimental read-only refresh, and working receiver controls are preserved. This release has not been compiled or tested on hardware.
