package com.example.sr7013remote

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RemoteScreen() } }
    }
}

private class ReceiverController(context: Context) {
    private val prefs = context.getSharedPreferences("receiver", Context.MODE_PRIVATE)
    var host: String
        get() = prefs.getString("host", "") ?: ""
        set(value) { prefs.edit().putString("host", value.trim()).apply() }

    // Denon/Marantz AVR direct-command endpoint. Verify command availability on SR7013 firmware.
    suspend fun command(command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val encodedCommand = URLEncoder.encode(command, StandardCharsets.UTF_8.name()).replace("+", "%20")
            val url = URL("http://$address:8080/goform/formiPhoneAppDirect.xml?$encodedCommand")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2500
                readTimeout = 2500
                useCaches = false
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Receiver returned HTTP $code")
                connection.inputStream.use { it.readBytes() }
                Unit
            } finally { connection.disconnect() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteScreen() {
    val context = LocalContext.current
    val controller = remember { ReceiverController(context) }
    var ip by remember { mutableStateOf(controller.host) }
    var message by remember { mutableStateOf("Enter your SR7013 IP address, then tap Save & Test.") }
    var busy by remember { mutableStateOf(false) }
    var inputExpanded by remember { mutableStateOf(false) }
    var mainInputExpanded by remember { mutableStateOf(false) }
    var zone2InputExpanded by remember { mutableStateOf(false) }
    var zone3InputExpanded by remember { mutableStateOf(false) }
    var outdoorModeExpanded by remember { mutableStateOf(false) }
    var selectedMainInput by remember { mutableStateOf("CBL/SAT" to "SICBL") }
    var selectedZone2Input by remember { mutableStateOf("HEOS" to "Z2HEOS") }
    var selectedZone3Input by remember { mutableStateOf("CBL/SAT" to "Z3SAT/CBL") }
    var outdoorMode by remember { mutableStateOf("Follow Main Zone") }
    val inputs = listOf(
        "CBL/SAT" to "SICBL", "Blu-ray" to "SIBD", "Game" to "SIGAME",
        "Media Player" to "SIMPLAY", "TV Audio" to "SITV", "AUX1" to "SIAUX1",
        "Bluetooth" to "SIBT", "HEOS" to "SIHEOS"
    )
    val scope = rememberCoroutineScope()

    fun send(command: String, label: String = command) {
        scope.launch {
            busy = true
            message = "Sending $label…"
            val result = controller.command(command)
            message = result.fold({ "$label command sent. Receiver response confirmed at HTTP level; state has not yet been read back." },
                { "Could not send $label: ${it.message ?: "connection error"}" })
            busy = false
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("SR7013 Remote", fontWeight = FontWeight.Bold) })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("MARANTZ • LOCAL NETWORK", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(
                value = ip, onValueChange = { ip = it },
                label = { Text("Receiver IP address") },
                placeholder = { Text("e.g. 192.168.1.50") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                controller.host = ip
                send("PW?", "Connection test (port 8080)")
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else "Save & Test")
            }
            Text(message, style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("POWER & VOLUME", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("PWON", "Power on") }
                RemoteButton("Standby", Modifier.weight(1f)) { send("PWSTANDBY", "Standby") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("MVDOWN", "Volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("MUON", "Mute on") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("MVUP", "Volume up") }
            }
            RemoteButton("Unmute", Modifier.fillMaxWidth()) { send("MUOFF", "Unmute") }

            HorizontalDivider()
            Text("INPUTS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(expanded = inputExpanded, onExpandedChange = { inputExpanded = it }) {
                OutlinedTextField(
                    value = "Choose input", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = inputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = inputExpanded, onDismissRequest = { inputExpanded = false }) {
                    inputs.forEach { (label, cmd) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            inputExpanded = false
                            selectedMainInput = label to cmd
                            send(cmd, "Input: $label")
                        })
                    }
                }
            }

            HorizontalDivider()
            Text("SOUND MODES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            listOf(
                "Auto" to "MSAUTO", "Stereo" to "MSSTEREO", "Direct" to "MSDIRECT",
                "Pure Direct" to "MSPURE DIRECT", "Dolby Surround" to "MSDOLBY SURROUND",
                "DTS Neural:X" to "MSDTS NEURAL:X"
            ).forEach { (label, cmd) ->
                RemoteButton(label, Modifier.fillMaxWidth()) { send(cmd, "Sound mode: $label") }
            }

            HorizontalDivider()
            Text("ZONE 2 • JBL DECK", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("Outdoor speakers", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("Z2ON", "JBL Deck power on") }
                RemoteButton("Off", Modifier.weight(1f)) { send("Z2OFF", "JBL Deck power off") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("Z2DOWN", "JBL Deck volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("Z2MUON", "JBL Deck mute") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("Z2UP", "JBL Deck volume up") }
            }
            RemoteButton("Unmute JBL Deck", Modifier.fillMaxWidth()) { send("Z2MUOFF", "JBL Deck unmute") }
            ExposedDropdownMenuBox(expanded = zone2InputExpanded, onExpandedChange = { zone2InputExpanded = it }) {
                OutlinedTextField(
                    value = "JBL Deck source: ${selectedZone2Input.first}", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = zone2InputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = zone2InputExpanded, onDismissRequest = { zone2InputExpanded = false }) {
                    inputs.forEach { (label, mainCmd) ->
                        val zoneCmd = when (mainCmd) {
                            "SICBL" -> "Z2SAT/CBL"
                            "SIBD" -> "Z2BD"
                            "SIGAME" -> "Z2GAME"
                            "SIMPLAY" -> "Z2MPLAY"
                            "SITV" -> "Z2TV"
                            "SIAUX1" -> "Z2AUX1"
                            "SIBT" -> "Z2BT"
                            else -> "Z2HEOS"
                        }
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            zone2InputExpanded = false
                            selectedZone2Input = label to zoneCmd
                            send(zoneCmd, "JBL Deck source: $label")
                        })
                    }
                }
            }

            HorizontalDivider()
            Text("ZONE 3", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("Z3ON", "Zone 3 power on") }
                RemoteButton("Off", Modifier.weight(1f)) { send("Z3OFF", "Zone 3 power off") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("Z3DOWN", "Zone 3 volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("Z3MUON", "Zone 3 mute") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("Z3UP", "Zone 3 volume up") }
            }
            RemoteButton("Unmute Zone 3", Modifier.fillMaxWidth()) { send("Z3MUOFF", "Zone 3 unmute") }
            ExposedDropdownMenuBox(expanded = zone3InputExpanded, onExpandedChange = { zone3InputExpanded = it }) {
                OutlinedTextField(
                    value = "Zone 3 source: ${selectedZone3Input.first}", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = zone3InputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = zone3InputExpanded, onDismissRequest = { zone3InputExpanded = false }) {
                    inputs.forEach { (label, mainCmd) ->
                        val zoneCmd = when (mainCmd) {
                            "SICBL" -> "Z3SAT/CBL"
                            "SIBD" -> "Z3BD"
                            "SIGAME" -> "Z3GAME"
                            "SIMPLAY" -> "Z3MPLAY"
                            "SITV" -> "Z3TV"
                            "SIAUX1" -> "Z3AUX1"
                            "SIBT" -> "Z3BT"
                            else -> "Z3HEOS"
                        }
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            zone3InputExpanded = false
                            selectedZone3Input = label to zoneCmd
                            send(zoneCmd, "Zone 3 source: $label")
                        })
                    }
                }
            }

            HorizontalDivider()
            Text("OUTDOOR MUSIC", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("One-tap JBL Deck shortcut", style = MaterialTheme.typography.bodySmall)
            ExposedDropdownMenuBox(expanded = outdoorModeExpanded, onExpandedChange = { outdoorModeExpanded = it }) {
                OutlinedTextField(
                    value = outdoorMode, onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = outdoorModeExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = outdoorModeExpanded, onDismissRequest = { outdoorModeExpanded = false }) {
                    listOf("Follow Main Zone", "Use JBL Deck source").forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = {
                            outdoorMode = option
                            outdoorModeExpanded = false
                        })
                    }
                }
            }
            Button(onClick = {
                scope.launch {
                    busy = true
                    message = "Starting Outdoor Music…"
                    val powerResult = controller.command("Z2ON")
                    val sourceResult = if (outdoorMode == "Follow Main Zone") {
                        val zoneCmd = selectedMainInput.second.replaceFirst("SI", "Z2")
                            .let { if (it == "Z2CBL") "Z2SAT/CBL" else if (it == "Z2BD") "Z2BD" else it }
                        controller.command(zoneCmd)
                    } else {
                        controller.command(selectedZone2Input.second)
                    }
                    message = if (powerResult.isSuccess && sourceResult.isSuccess) {
                        "Outdoor Music commands sent to JBL Deck. Receiver state has not been read back."
                    } else {
                        "Outdoor Music could not complete: " +
                            (powerResult.exceptionOrNull()?.message ?: sourceResult.exceptionOrNull()?.message ?: "receiver command failed")
                    }
                    busy = false
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else "▶ Start Outdoor Music")
            }

            HorizontalDivider()
            Text("IMPORTANT", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
                "Network-fix build: commands use the receiver's local HTTP direct-command interface on port 8080. " +
                "Command support and exact input/mode names can vary by SR7013 firmware. " +
                "Zone 2/3 commands and source names depend on receiver firmware and need testing on your SR7013. " +
                "The Outdoor Music shortcut sends power and source commands but cannot verify the resulting zone state. " +
                "Do not expose the receiver control port to the public internet.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun RemoteButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 48.dp)) {
        Text(label)
    }
}
