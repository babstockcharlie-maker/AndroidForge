# SR7013 Remote — Android starter project

A native Android Studio starter for a locally networked Marantz SR7013 remote.

## Current scope
- Stores a receiver IP address on the phone
- Basic power, volume, mute, input and sound-mode command buttons
- Uses the Denon/Marantz local HTTP direct-command endpoint
- No cloud account or third-party server

## Important limitations
This is source code, not a compiled or tested APK. It has not been run against a physical SR7013. Validate endpoint and command compatibility on the target receiver before relying on it. Some command strings and input names may need correction for the receiver's firmware.

Not yet implemented: discovery, reliable read-back/status polling, Scenes, Audyssey, speaker setup, channel trims, signal information, tuner, HEOS metadata, Zone 2/3 pages, widgets, backup/restore, localization and full remote navigation.

## Build
1. Open this folder in a recent Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android phone.
5. Connect phone and receiver to the same trusted home Wi-Fi/LAN.
6. On the SR7013, enable Network Control (Always On if you want standby wake), then find its IP under Network > Information.
7. Enter the IP in the app and test one command at a time.

## Network safety
The starter uses plain HTTP on the local network because this receiver's direct-control interface is legacy HTTP. Do not expose the receiver to the public internet or forward its control port on your router. Keep it on a trusted LAN.


## Build compatibility update

This archive uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 so it can build with Gradle 8.9, which is the system Gradle reported by the first AndroidForge build logs. It targets compileSdk 35. This is a starter project and has not been tested against a physical SR7013; receiver commands and state read-back still need validation.


## JVM target compatibility fix

This version explicitly sets both Java compilation and Kotlin compilation to JVM 17, resolving the mismatch reported by AndroidForge (Java 1.8 versus Kotlin 17). It has not yet been verified by a successful remote build.


## SR7013 network endpoint update

This version targets the Denon/Marantz direct-command endpoint on HTTP port 8080 (`/goform/formiPhoneAppDirect.xml`). The receiver's browser web-control UI at HTTPS port 10443 is a different service; HTTP port 80 redirects to it on this user's receiver. This version is a diagnostic attempt and must be tested against the actual SR7013. If the direct command endpoint does not respond on port 8080, inspect the receiver-specific network behavior before further changes.


## Version 2 draft: Zone controls and Outdoor Music

This draft adds UI controls for Main Zone, Zone 2 (labelled **JBL Deck**), and Zone 3, plus an Outdoor Music shortcut with two modes: follow the Main Zone source selected within this app, or use the JBL Deck source selected in the Zone 2 controls.

**Important:** Zone 2/Zone 3 direct-command strings and source mappings have not been verified against this user's SR7013. Build and test cautiously, one command at a time. The shortcut cannot read back or confirm actual receiver state. If a command is unsupported, correct its command mapping based on receiver behavior before relying on it. The "Follow Main Zone" mode follows the Main Zone input selected in this app; it does not detect input changes made with another remote or the receiver's web UI.


## Version 4: dB volume slider

This draft adds a volume slider for the currently selected zone, displays volume status in dB, and initializes the slider at -55.0 dB to match the user's preferred startup level. The slider spans -79.5 dB to +18.0 dB. Please test the absolute-volume command mapping on the receiver at a low listening level before relying on it; Denon/Marantz firmware/protocol response formatting can vary.


## Version 5.1 correction
This project explicitly displays Bass & Treble controls in the Main Zone section. Bass and Treble range from −6 dB to +6 dB. Tone On/Off and Reset 0 dB controls are provided. On SR7013, tone adjustment is stored per input and is unavailable in Direct/Pure Direct modes or when Dynamic EQ is on. Confirm behavior on the receiver.
