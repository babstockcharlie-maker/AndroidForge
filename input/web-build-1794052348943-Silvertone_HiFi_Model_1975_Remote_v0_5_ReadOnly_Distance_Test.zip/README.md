Silvertone Hi-Fi Model 1975 Remote — v0.5.0 experimental read-only speaker distance refresh

AndroidForge / Android Studio source project. Build not verified locally.

Added Receiver Distances section and Refresh Distances button on Speaker Setup page. Attempts GET http://<configured receiver IP>:11080/ajax/speakers/get_config?type=4, a community-documented Denon/Marantz HTTP AJAX endpoint verified on some newer receivers, NOT yet verified on Marantz SR7013.

Parses XML Distances Unit (1=feet, 2=meters), Speaker index 0 Front Left and 1 Front Right. Displays two decimal places. Does not alter locally stored values or send any receiver calibration changes. Explicitly reports unsupported endpoints and network errors. Phone must be on the receiver's reachable local network. If both readings are available, test changing FL from 3.20m to 3.50m on receiver and press Refresh; FR should remain 3.20m.

Original v0.4 Speaker Setup and main remote UI preserved. Other speaker channel mappings are not claimed as verified; manual local layout selection remains.

Reference: https://github.com/alsak0de/marantz-denon-mqtt/blob/main/docs/telnet/AUDYSSEY.md
