package com.example.sr7013remote

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RemoteScreen() } }
    }
}

private class ReceiverController(context: Context) {
    private val prefs = context.getSharedPreferences("receiver", Context.MODE_PRIVATE)
    var host: String
        get() = prefs.getString("host", "") ?: ""
        set(value) { prefs.edit().putString("host", value.trim()).apply() }

    // Denon/Marantz AVR direct-command endpoint. Verify command availability on SR7013 firmware.
    suspend fun command(command: String): Result<Unit> = withContext(Dispatchers.IO) {
        val address = host.trim()
        if (address.isBlank()) return@withContext Result.failure(IllegalStateException("Enter the receiver IP address first."))
        runCatching {
            val url = URL("http://$address/goform/formiPhoneAppDirect.xml?${command}")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2500
                readTimeout = 2500
                useCaches = false
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Receiver returned HTTP $code")
                connection.inputStream.use { it.readBytes() }
            } finally { connection.disconnect() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemoteScreen() {
    val context = LocalContext.current
    val controller = remember { ReceiverController(context) }
    var ip by remember { mutableStateOf(controller.host) }
    var message by remember { mutableStateOf("Enter your SR7013 IP address, then tap Save & Test.") }
    var busy by remember { mutableStateOf(false) }
    var inputExpanded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun send(command: String, label: String = command) {
        scope.launch {
            busy = true
            message = "Sending $label…"
            val result = controller.command(command)
            message = result.fold({ "$label command sent. Receiver response confirmed at HTTP level; state has not yet been read back." },
                { "Could not send $label: ${it.message ?: "connection error"}" })
            busy = false
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("SR7013 Remote", fontWeight = FontWeight.Bold) })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("MARANTZ • LOCAL NETWORK", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(
                value = ip, onValueChange = { ip = it },
                label = { Text("Receiver IP address") },
                placeholder = { Text("e.g. 192.168.1.50") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                controller.host = ip
                send("PW?", "Connection test")
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else "Save & Test")
            }
            Text(message, style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("POWER & VOLUME", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("Power On", Modifier.weight(1f)) { send("PWON", "Power on") }
                RemoteButton("Standby", Modifier.weight(1f)) { send("PWSTANDBY", "Standby") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RemoteButton("− Volume", Modifier.weight(1f)) { send("MVדOWN".replace("ד","D"), "Volume down") }
                RemoteButton("Mute", Modifier.weight(1f)) { send("MUON", "Mute on") }
                RemoteButton("+ Volume", Modifier.weight(1f)) { send("MVUP", "Volume up") }
            }
            RemoteButton("Unmute", Modifier.fillMaxWidth()) { send("MUOFF", "Unmute") }

            HorizontalDivider()
            Text("INPUTS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(expanded = inputExpanded, onExpandedChange = { inputExpanded = it }) {
                OutlinedTextField(
                    value = "Choose input", onValueChange = {}, readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = inputExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = inputExpanded, onDismissRequest = { inputExpanded = false }) {
                    listOf(
                        "CBL/SAT" to "SICBL", "Blu-ray" to "SIBD", "Game" to "SIGAME",
                        "Media Player" to "SIMPLAY", "TV Audio" to "SITV", "AUX1" to "SIAUX1",
                        "Bluetooth" to "SIBT", "HEOS" to "SIHEOS"
                    ).forEach { (label, cmd) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            inputExpanded = false; send(cmd, "Input: $label")
                        })
                    }
                }
            }

            HorizontalDivider()
            Text("SOUND MODES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            listOf(
                "Auto" to "MSAUTO", "Stereo" to "MSSTEREO", "Direct" to "MSDIRECT",
                "Pure Direct" to "MSPURE DIRECT", "Dolby Surround" to "MSDOLBY SURROUND",
                "DTS Neural:X" to "MSDTS NEURAL:X"
            ).forEach { (label, cmd) ->
                RemoteButton(label, Modifier.fillMaxWidth()) { send(cmd, "Sound mode: $label") }
            }

            HorizontalDivider()
            Text("IMPORTANT", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
                "Starter build: commands use the receiver's local HTTP direct-command interface. " +
                "Command support and exact input/mode names can vary by SR7013 firmware. " +
                "Advanced Maestro-style features—Audyssey adjustments, speaker layout/distances/levels, " +
                "signal details, scenes, tuner, HEOS metadata, widgets, and Zone 2/3—are not implemented yet. " +
                "We should validate basic control against your receiver before adding those pages.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun RemoteButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 48.dp)) {
        Text(label)
    }
}
