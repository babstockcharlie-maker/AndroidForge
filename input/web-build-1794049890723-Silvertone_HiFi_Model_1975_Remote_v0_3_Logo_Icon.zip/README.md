# Silvertone Hi-Fi — Model 1975 Remote v0.3

Commercial-development branch only. Personal Marantz project unchanged.

## Changes
- New transparent Silvertone Hi-Fi script wordmark adapted from the approved concept render, used in header.
- Coordinated champagne script graphic in footer.
- Custom walnut, aluminum and illuminated-knob launcher icon replacing the Android default icon.
- Generic Main Zone / Zone 2 / Zone 3 naming retained.
- Receiver control implementation unchanged from v0.2.

## Build
Import source ZIP in AndroidForge. This source has not been compiled or device-tested here.

## Connection
Receiver IP defaults to the personal development device (192.168.0.3). Set a reachable receiver IP on the same LAN before testing; cellular connections will not normally reach a private 192.168.x.x address.

## Commercial release
Silvertone is an existing brand name: clear trademark usage before sale. Review image assets and third-party licenses before publishing.
