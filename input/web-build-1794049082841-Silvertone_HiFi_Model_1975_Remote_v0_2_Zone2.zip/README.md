# Silvertone Hi-Fi — Model 1975 Remote

Independent AndroidForge / Android Studio source project, prototype v0.1.0.

## Included
- Original Silvertone Hi-Fi raster wordmark and Model 1975 script artwork, created from available system fonts (font files are not bundled).
- Brushed aluminum and walnut interface, blue controls, decorative amber meter bars.
- Receiver commands and status functionality carried over from the personal Marantz V6.2 source.
- Separate Android package: `com.silvertone.hifi.remote`.
- Main Zone, Zone 2, Zone 3, volume, inputs, tone and receiver address configuration.

## Build
Import ZIP into AndroidForge or Android Studio and build the APK. Android Gradle Plugin / Kotlin plugin versions are managed by your build environment, as with the prior project. This ZIP is source, not a prebuilt APK.

## Commercial release checklist
**Not ready for sale or published release.** 'Silvertone' has been used as a consumer audio brand historically; trademark clearance is required before adopting it commercially. Test on hardware, review privacy/security (HTTP control on LAN), verify dependencies and licenses, and remove any misleading manufacturer affiliation claims. The app communicates using receiver-specific network commands; it has not been validated against additional manufacturers or models.
