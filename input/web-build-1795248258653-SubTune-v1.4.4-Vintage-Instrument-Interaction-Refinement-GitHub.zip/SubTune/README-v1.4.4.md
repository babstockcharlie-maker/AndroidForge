# SubTune 1.4.4 — Q Branch Interaction Refinements

Based on the working SubTune 1.4.3 comparison-table alignment fix.

- Rounded outside corners for the Port / Cone / Room and Auto / Manual segmented controls; internal joins remain flush.
- Visible, illuminated in-progress state for the primary Run button, with specific active labels for sweep, manual tone, and calibration.
- The 50 Hz Calibration button also illuminates and announces Background or Tone capture while active.
- A compact dark progress strip replaces the former plain-text status. During sweeps it shows location and point count only, not the live Hz (already shown in the main display).
- Calibration shows 0 Hz during background collection and 50 Hz during tone collection in the single central live-frequency display.
- Clear STOPPING state while the audio engine shuts down.

The existing audio engine, knob clamp/scroll behavior, history persistence, comparison grid, and CSV export have not been rewritten.

## Test checklist
1. Compile Android debug build through AndroidForge / GitHub Actions.
2. Confirm first/last segments have rounded exterior corners in both groups.
3. Start a Port Auto sweep: Run becomes teal TEST RUNNING, STOP is enabled, and progress reads Port sweep running • n/N points (no second Hz counter).
4. Tap STOP during a sweep: STOPPING state appears, and frequency returns to 0 Hz after cleanup.
5. Start Calibration: Calibration bar illuminates, switches background → tone, then returns to normal.
6. Manual mode: continuous until user stops; rotary knobs preserve v1.3.3 fixes.
7. Verify table columns align after selecting multiple sessions.

Archive integrity is checked before delivery; Android compilation/on-device results require testing on a device/CI.
