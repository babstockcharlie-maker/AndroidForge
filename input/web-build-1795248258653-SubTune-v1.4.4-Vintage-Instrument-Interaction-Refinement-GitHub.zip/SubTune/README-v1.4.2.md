# SubTune v1.4.2 — Instrument Panel Refinement

This is a **visual-only refinement of v1.4.1**, preserving the exact 1.3.3 rotary touch mapping and the existing measurement/audio logic.

## Updated
- Original-render SubTune script logo as transparent, density-independent Android image asset.
- Recessed chrome/glass bezels for display, response graph, history and comparison.
- True continuous framed segmented switches for Port/Cone/Room and Auto/Manual.
- More restrained metal knob machining with inset cyan readout plaques.
- Brighter teal chart grid and location-specific line colors (Port teal, Cone amber, Room blue).
- History and comparison rows styled as dark instrument windows.

## Intentionally preserved
- Working rotary angle limits and no-scroll touch behavior.
- AudioTrack continuous tone and manual-until-STOP behavior.
- Automatic 5–120 Hz configuration, calibration and safety warning.
- CSV export, saved histories, persistent app ID `com.subtune.app`.

No Android compilation/device test has been performed in this environment. Build in AndroidForge, retaining the last working v1.4.1 APK until verification.
