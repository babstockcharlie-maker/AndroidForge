# SubTune v1.4.3 — Comparison Table Alignment Fix

Based on working v1.4.2 vintage-instrument source.

## Correction
- Replaced manually spaced strings with real column-aligned Android TextViews.
- Header and numeric rows now use the same fixed column widths, guaranteeing alignment of Hz, test IDs, and values.
- In two-session comparisons, Test 1 / Test 2 / Δ dB are aligned with their corresponding values.
- For additional selected sessions, the entire table scrolls horizontally, keeping headings and data in sync.
- The table body scrolls vertically inside a compact measurement window, with the header remaining visible.
- Preserves stored measurements, audio engine, rotary/scroll fixes, frequency sweeps, graph, and existing controls.

## Validation
- Source and archive integrity checked.
- Android compilation and device tests are still required in AndroidForge.
- Keep v1.4.2 installed until v1.4.3 is confirmed working.
