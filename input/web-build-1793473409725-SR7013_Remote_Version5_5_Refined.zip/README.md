# SR7013 Remote — Version 5.5 (1060B refinement)

Based on the user-tested working Version 5.4.1 project. Import the source project into AndroidForge to build an APK.

## Changes
- One POWER toggle for each selected zone; subtle blue ring indicates an ON state. State is based on receiver replies where available, or successful power-command submission until refreshed.
- Circular brushed-metal volume slider thumb.
- Status automatically requested after a successful command (and when switching zones); manual Refresh Status remains available. The slider updates from the receiver's reported volume when it can be parsed.
- Approximately 10% tighter vertical spacing, retaining touch-friendly button dimensions.
- Keeps the Marantz 1060B-inspired silver/walnut theme and the inscription: Inspired by Marantz 1060B · Est. 1975.
- Outdoor Music follow-Main source command corrected to use the Zone 2 prefix.

## Important
No local Android Gradle compilation was available. Build with AndroidForge and share the GitHub Actions logs if compilation fails. An HTTP success only confirms command delivery, not necessarily a changed receiver setting. Receiver status polling uses TCP port 23, so Network Control must be enabled. This build has not yet been verified on the actual SR7013.
