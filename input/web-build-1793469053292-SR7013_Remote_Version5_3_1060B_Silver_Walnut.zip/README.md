# Marantz SR7013 Remote — Version 5.3
## 1060B Silver & Walnut Edition

This project is based on Version 4's original Zone 2 implementation. The JBL Deck Zone 2 power, volume up/down, mute/unmute, volume slider, and source-selection command paths are retained from that known-working version.

### Appearance
- Silver faceplate with a warm walnut frame/side rails
- Dark recessed-looking controls with silver outlines
- Marantz-blue accent colour
- 1060B-inspired heading and typography

### Main Zone
- Original Main Zone power, volume, input and sound-mode controls
- Bass/treble preset buttons using the Main Zone protocol commands
- Tone enable command

### JBL Deck / Zone 2
- Original Version 4 Zone 2 power, volume, mute and source controls preserved
- Separate Zone 2 bass/treble preset buttons are included as experimental controls.
- IMPORTANT: Zone 2 tone command support has not been confirmed for the SR7013. The HTTP endpoint may acknowledge a command without applying it. Test carefully and verify the receiver's actual tone settings.

### Zone 3, status and outdoor shortcut
Retained from Version 4.

### Connection
- HTTP direct commands: port 8080
- Live status: TCP port 23
- Default IP is entered in the app; the app remembers it.

Build the Android project in AndroidForge as with previous versions. This is a source project ZIP, not a prebuilt APK.
