Silvertone Hi-Fi Model 1975 Remote v1.2 — HTML Structure & Distance Discovery

Based on v1.1 source. New diagnostic: run TLS certificate inspection, review fingerprint, then button 4 to inspect HTML structure of /speakers/speakers.html. A single pinned HTTPS GET; no scripts executed or forms submitted. Report includes short raw HTML snippets, so review before sharing. No live distance synchronization claimed.

VersionCode 12; versionName 1.2.0. Existing controls and artwork preserved. Source has not been compiled or tested against receiver.
