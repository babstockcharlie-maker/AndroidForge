Silvertone Hi-Fi Model 1975 Remote v1.3 — JavaScript Interface Discovery

Based on the v1.2 source. Preserves remote UI and existing diagnostic functions.

New: Receiver Diagnostics > 5 · INSPECT JAVASCRIPT — V1.3
After running TLS certificate diagnosis, this reads four known static JS paths over certificate-pinned HTTPS GET, with no redirects or scripts executed.
Files: /speakers/SpeakersServerInterface.js, /speakers/SpeakersSettings.js, /GlobalsServerInterface.js, /GlobalsSettings.js.
Reports HTTP status, keyword clues, and up to 16 bounded source lines per file. Review reports before sharing. No speaker values are claimed as live.

Not compiled or tested on the receiver. Keep your previous working APK.
