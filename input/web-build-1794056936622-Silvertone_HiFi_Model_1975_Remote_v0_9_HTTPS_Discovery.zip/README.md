# Silvertone Hi-Fi V0.9 — HTTPS Web Discovery

AndroidForge / Android Studio source ZIP, based on V0.8. Existing remote, speaker setup, styling, icon, port scanner and previous diagnostics remain.

## New diagnostic workflow
1. Connect phone to same LAN as the SR7013.
2. Receiver Diagnostics → HTTPS WEB DISCOVERY — V0.9.
3. Tap **1 · INSPECT HTTPS CERTIFICATE**. This only performs a TLS handshake and displays the certificate's SHA-256 fingerprint and subject.
4. If you recognize/trust this local receiver certificate, tap **2 · TRUST THIS FINGERPRINT & INSPECT**. Only then will the app issue read-only HTTPS GET requests to port 10443, using certificate fingerprint pinning and restricting requests to the configured receiver.
5. Tap **COPY V0.9 HTTPS REPORT** and share the result.

Only GET / and up to eight same-origin, absolute-path static JavaScript references are fetched. No forms, configuration endpoints or calibration commands are submitted. No live speaker distances are read yet. The certificate is not trusted globally and the trust decision is not persisted. If the receiver certificate changes, HTTPS requests fail until a new inspection and explicit approval.

Reference values from browser: main FL/FR 3.23 m, dedicated 2ch FL/FR 2.52 m (earlier). Not live readings.

**Not compiled or tested against receiver. Keep previous working APK.**
