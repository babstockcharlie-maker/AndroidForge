SubTune v1.3.3: Fix rotary dead-zone wraparound. Touch just below minimum clamps to minimum instead of jumping to maximum. Preserve scroll interception fix from v1.3.2.
