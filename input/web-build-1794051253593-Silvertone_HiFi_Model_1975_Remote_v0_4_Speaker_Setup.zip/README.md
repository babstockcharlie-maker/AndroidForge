# Silvertone Hi-Fi — Model 1975 Remote V0.4

AndroidForge source project, derived from Silvertone V0.3. Separate from personal Marantz project.

## New: Speaker Setup
- New Speaker Setup button on remote page, with Back navigation.
- Feet and meters toggle; values stored internally in meters to avoid conversion drift.
- Layout presets: 2.0, 5.1, 7.1, 5.1.2, 7.1.4. Select manually to match enabled receiver channels.
- Individual speaker and subwoofer distance controls; changes saved on-device using SharedPreferences.
- Reset current layout's values to 3.0 m.

**Safety and limitations:** These are LOCAL planning values. The app does not read receiver speaker topology or distances and does not write calibration values to the receiver. Presets are not a guarantee of compatibility with every receiver. A receiver-specific read/write protocol must be verified before implementing an Apply function. The existing receiver remote controls are unchanged.

Build through AndroidForge/GitHub Actions as with earlier versions. Not compiled or hardware-tested here.
