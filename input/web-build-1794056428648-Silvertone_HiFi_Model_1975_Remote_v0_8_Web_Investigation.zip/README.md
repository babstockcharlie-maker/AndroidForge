# Silvertone Hi-Fi V0.8 — Web Interface Investigation

AndroidForge / Android Studio source project. Based on the supplied V0.7 project, retaining the remote, speaker setup, Silvertone branding and existing diagnostics.

## New feature
Receiver Diagnostics → Web Interface Investigation. Read-only GET of the configured receiver's HTTP homepage and at most eight same-origin JavaScript files referenced by that homepage. Reports HTTP response status, redirects, and keyword clues. No form submissions or receiver configuration commands. Copy Web Investigation Report to share findings.

## Test
1. Connect the phone to the receiver's local Wi-Fi network.
2. Open Receiver Diagnostics and choose INSPECT RECEIVER WEB INTERFACE.
3. Copy Web Investigation Report and share it for analysis.

Known reference from screenshots: Main FL/FR 3.23 m, separate two-channel FL/FR 2.52 m (earlier screenshot). These are NOT read by the app yet. This build does not implement automatic speaker distance synchronization. It is an investigation step.

This source ZIP has not been compiled or tested against the physical receiver. Keep the last known working APK available.
