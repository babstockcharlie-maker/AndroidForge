Marantz Remote V6.1 — Vintage Typography Edition

Based on personal V6.0. Header and footer Marantz wordmark are transparent PNG graphics extracted from the earlier visual concept render (approximation, not an official master logo). Model 7013 Remote script and all functional receiver logic retained. Commercial Silvertone project is untouched.

Import ZIP into AndroidForge. Build and test on device.
