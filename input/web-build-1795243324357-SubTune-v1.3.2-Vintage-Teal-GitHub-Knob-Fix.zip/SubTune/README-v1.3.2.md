# SubTune v1.3.2 — rotary touch fix

- Rotary knobs prevent the parent ScrollView from intercepting touch gestures during adjustment.
- Scroll handling is restored on finger release or gesture cancellation.
- Existing audio engine, measurement, and visual layout are unchanged.
