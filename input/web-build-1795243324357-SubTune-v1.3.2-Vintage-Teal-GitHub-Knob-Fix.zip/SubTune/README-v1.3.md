# SubTune v1.3 Vintage Teal — source ZIP

Updates to the supplied v1.2.1 project:
- Port, Cone and Room measurement selection
- Selectable 5/10/15/20/25/30/40 Hz sweep start and 40/60/80/90/100/120 Hz end
- Manual mode plays until STOP; frequency knob adjusts the running tone smoothly and live measurements update the plot
- Frequency counter resets to 0 Hz after stopping/completion
- Walnut-colored outer trim, brushed-silver face and cursive teal logotype
- Response graph scales to selected and historical frequency/dB ranges
- Retains saved measurement sessions and CSV export

Build: extract SubTune folder contents to GitHub repository root, run Actions > Build SubTune APK, or upload ZIP to AndroidForge.

Caution: 5–20 Hz can cause severe cone excursion; phone microphones are often unreliable at infrasonic frequencies. Start at very low volume.

This source was not compiled or tested on an Android device in this environment. Please retain the previous working APK until v1.3 is verified.
