# SubTune v1.2 — Vintage Teal Edition (source / GitHub build)

Based on the supplied v1.1 FineSweep source. Retains its continuous phase-preserving AudioTrack sine generator, 100 ms frequency glide, 450 ms settling, 900 ms microphone capture, 5-second countdown, and microphone acquisition. **This source has not been compiled or tested on a device in this environment.**

## Build on GitHub
1. Create or open a GitHub repository.
2. Place the **contents** of the `SubTune` directory at the repository root, including `.github/workflows/build-apk.yml`.
3. Open Actions > Build SubTune APK > Run workflow.
4. Download the `SubTune-debug-apk` workflow artifact, unzip it, and install `app-debug.apk`.

## Changes
- Brushed silver face, teal-on-black response plot and readout, vintage script-style title, circular touch-controlled frequency and level knobs.
- Side-by-side Port/Cone and Auto/Manual selection.
- 50 Hz calibration retained via its own button.
- Frequency readout updates at each test step. Live response graph updates as readings arrive, with connected lines and no dot markers.
- Automatic test sessions saved in Android app preferences; history checkboxes select multiple sessions to overlay. Comparison table includes signed difference for exactly two selected tests (Test 2 minus Test 1). Sessions survive app restarts.
- Share CSV exports all saved session readings using the original column names. CLEAR ACTIVE deselects current active session without deleting saved data. DELETE SAVED asks confirmation before deleting selected sessions, or all when none selected.

## Important safety and measurement notes
- Start with amplifier gain low. Stop for excessive cone excursion, particularly below the expected port tuning frequency.
- Tone level 1–20% is digital signal amplitude, **not** calibrated acoustic loudness.
- Disable third-party equalizers for comparable measurements. Microphone and Bluetooth processing may affect readings.
- Graphs show relative microphone dBFS, not calibrated SPL. Curves are connected without adding synthetic samples or heavy smoothing.
- Frequency rotary knob selects 25–90 Hz in 1 Hz steps. Automatic sweep uses all 66 frequencies; manual mode captures one selected frequency.
- The GitHub workflow builds an APK. The ZIP itself is source, not an APK.
