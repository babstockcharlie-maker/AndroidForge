plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.subtune.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.subtune.app"; minSdk = 26; targetSdk = 28; versionCode = 4; versionName = "1.3" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
