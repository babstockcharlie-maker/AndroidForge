# SR7013 Remote — Android starter project

A native Android Studio starter for a locally networked Marantz SR7013 remote.

## Current scope
- Stores a receiver IP address on the phone
- Basic power, volume, mute, input and sound-mode command buttons
- Uses the Denon/Marantz local HTTP direct-command endpoint
- No cloud account or third-party server

## Important limitations
This is source code, not a compiled or tested APK. It has not been run against a physical SR7013. Validate endpoint and command compatibility on the target receiver before relying on it. Some command strings and input names may need correction for the receiver's firmware.

Not yet implemented: discovery, reliable read-back/status polling, Scenes, Audyssey, speaker setup, channel trims, signal information, tuner, HEOS metadata, Zone 2/3 pages, widgets, backup/restore, localization and full remote navigation.

## Build
1. Open this folder in a recent Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android phone.
5. Connect phone and receiver to the same trusted home Wi-Fi/LAN.
6. On the SR7013, enable Network Control (Always On if you want standby wake), then find its IP under Network > Information.
7. Enter the IP in the app and test one command at a time.

## Network safety
The starter uses plain HTTP on the local network because this receiver's direct-control interface is legacy HTTP. Do not expose the receiver to the public internet or forward its control port on your router. Keep it on a trusted LAN.


## Build compatibility update

This archive uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 so it can build with Gradle 8.9, which is the system Gradle reported by the first AndroidForge build logs. It targets compileSdk 35. This is a starter project and has not been tested against a physical SR7013; receiver commands and state read-back still need validation.


## JVM target compatibility fix

This version explicitly sets both Java compilation and Kotlin compilation to JVM 17, resolving the mismatch reported by AndroidForge (Java 1.8 versus Kotlin 17). It has not yet been verified by a successful remote build.
