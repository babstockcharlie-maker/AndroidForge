package com.subtune.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import android.view.View
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var sweepStart = 25
    private var sweepEnd = 90
    private lateinit var rangeLabel: TextView
    private lateinit var locationRoom: Button
    private val results = mutableListOf<Result>()
    private lateinit var status: TextView
    private lateinit var output: TextView
    private var selectedMode = "Automatic sweep"
    private var calibrationNext = false
    private var selectedPosition = "Cone"
    private var manualHz = 40
    private var amplitudePercent = 6
    private lateinit var frequencyReadout: TextView
    private lateinit var plot: ResponsePlot
    private lateinit var historyArea: LinearLayout
    private lateinit var comparisonArea: LinearLayout
    private lateinit var locationPort: Button
    private lateinit var locationCone: Button
    private lateinit var modeAuto: Button
    private lateinit var modeManual: Button
    private val sessions = mutableListOf<Session>()
    private var activeSession: Session? = null
    private var nextSessionId = 1
    private val selectedSessionIds = mutableSetOf<Int>()
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private var tone: AudioTrack? = null
    private val targetHz = AtomicInteger(40)
    private val toneEnabled = AtomicBoolean(false)
    private var toneWriter: Thread? = null
    private var recorder: AudioRecord? = null
    private var amplitudeFraction = 0.06
    private val sampleRate = 44100

    data class Result(val location:String, val hz:Int, val db:Double, val rmsDb:Double, val timestamp:String)
    data class Session(val id:Int, val location:String, val started:String, val points:MutableList<Result> = mutableListOf())

    private val teal = Color.rgb(0, 196, 190)
    private val ink = Color.rgb(15, 29, 34)
    private fun dp(v:Int) = (resources.displayMetrics.density * v).roundToInt()
    private fun panel(color:Int = ink, radius:Float=16f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius=dp(radius.toInt()).toFloat(); setStroke(dp(2), Color.rgb(91, 103, 103))
    }
    // Multi-layer chrome bezels are vector drawn at native screen resolution.
    // A single framed glass surface is used for each instrument window.
    private fun chromeBezel(radius:Int=16):LayerDrawable {
        fun layer(colors:IntArray, r:Int, stroke:Int):GradientDrawable =
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,colors).apply {
                cornerRadius=dp(r).toFloat();setStroke(dp(1),stroke)
            }
        val outside=layer(intArrayOf(Color.rgb(239,238,230),Color.rgb(111,120,119),Color.rgb(40,47,50),Color.rgb(203,205,195)),radius,Color.rgb(42,48,48))
        val inner=layer(intArrayOf(Color.rgb(17,26,29),Color.rgb(7,15,18)),radius-2,Color.rgb(9,13,15))
        val glass=layer(intArrayOf(Color.rgb(8,22,27),Color.rgb(7,17,20),Color.rgb(12,27,30)),radius-4,Color.rgb(45,79,80))
        return LayerDrawable(arrayOf<Drawable>(outside,inner,glass)).apply {
            setLayerInset(1,dp(3),dp(3),dp(3),dp(3))
            setLayerInset(2,dp(5),dp(5),dp(5),dp(5))
        }
    }
    private fun segmentRow():LinearLayout = row().apply {
        background=chromeBezel(22)
        setPadding(dp(5),dp(5),dp(5),dp(5))
        clipToOutline=true
    }
    private fun dividerBetween():View = View(this).apply { setBackgroundColor(Color.rgb(51,72,72)) }
    private fun texturedBackground(resId:Int):BitmapDrawable = BitmapDrawable(resources, BitmapFactory.decodeResource(resources,resId)).apply {
        gravity=android.view.Gravity.FILL
    }
    private fun instrumentButton(text:String, action:()->Unit):Button = button(text,action).apply {
        setTextColor(teal)
        background=chromeBezel(11)
        setShadowLayerCompat()
        stateListAnimator=null
    }
    private fun Button.setShadowLayerCompat() { elevation=dp(3).toFloat() }
    private fun label(text:String, size:Float=14f, color:Int=Color.BLACK):TextView = TextView(this).apply {
        this.text=text; textSize=size; setTextColor(color); gravity=android.view.Gravity.CENTER; setPadding(dp(3),dp(6),dp(3),dp(6))
    }
    private fun column():LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
    private fun row():LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=android.view.Gravity.CENTER_VERTICAL }
    private fun button(text:String, action:()->Unit):Button = Button(this).apply { this.text=text; textSize=12f; isAllCaps=false; setOnClickListener { action() } }
    private fun refreshToggles() {
        listOf(locationPort to (selectedPosition=="Port"),locationCone to (selectedPosition=="Cone"),locationRoom to (selectedPosition=="Room"),
            modeAuto to (selectedMode=="Automatic sweep"),modeManual to (selectedMode=="Manual frequency")).forEach { (b,active)->
            b.setTextColor(if(active) Color.rgb(235,255,252) else Color.rgb(209,218,216))
            b.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                if(active) intArrayOf(Color.rgb(0,29,32),Color.rgb(0,105,107),Color.rgb(0,174,169),Color.rgb(0,53,58))
                else intArrayOf(Color.rgb(2,7,9),Color.rgb(29,41,43),Color.rgb(4,11,14))).apply {
                cornerRadius=0f
                setStroke(dp(1),if(active) Color.rgb(0,191,183) else Color.rgb(14,29,30))
            }
            b.stateListAnimator=null
            b.elevation=0f
            b.minHeight=0;b.minimumHeight=0;b.minWidth=0;b.minimumWidth=0
            b.setPadding(0,0,0,0)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSessions()
        val outer=column().apply { setPadding(dp(12),dp(10),dp(12),dp(16)); background=texturedBackground(R.drawable.walnut_grain) }
        val scroll=ScrollView(this).apply { isFillViewport=true; addView(outer) }
        setContentView(scroll)
        val face=column().apply { setPadding(dp(12),dp(10),dp(12),dp(14)); background=texturedBackground(R.drawable.face_grain); elevation=dp(5).toFloat() }
        outer.addView(face)
        val masthead=row().apply { gravity=android.view.Gravity.CENTER_VERTICAL }
        masthead.addView(ScrewView(),LinearLayout.LayoutParams(dp(27),dp(42)))
        masthead.addView(AccentLinesView(),LinearLayout.LayoutParams(0,dp(46),.55f))
        val logo=ImageView(this).apply {
            setImageResource(R.drawable.subtune_logotype)
            scaleType=ImageView.ScaleType.FIT_CENTER
            adjustViewBounds=false
            contentDescription="SubTune"
        }
        masthead.addView(logo,LinearLayout.LayoutParams(0,dp(60),4.2f))
        masthead.addView(AccentLinesView(),LinearLayout.LayoutParams(0,dp(46),.55f))
        masthead.addView(ScrewView(),LinearLayout.LayoutParams(dp(27),dp(42)))
        face.addView(masthead)
        face.addView(label("ACOUSTIC MEASUREMENT SYSTEM",11f,Color.rgb(20,28,29)).apply {
            letterSpacing=.11f;typeface=Typeface.DEFAULT_BOLD
            setPadding(dp(2),0,dp(2),dp(12))
        })
        val controls=row();face.addView(controls)
        val left=column(); val right=column()
        controls.addView(left,LinearLayout.LayoutParams(0,-2,1f));controls.addView(right,LinearLayout.LayoutParams(0,-2,1f))
        left.addView(label("TEST LOCATION",12f));right.addView(label("TEST MODE",12f))
        val locRow=segmentRow();left.addView(locRow)
        locationPort=button("Port") { if(!running.get()){selectedPosition="Port";refreshToggles()} }
        locationCone=button("Cone") { if(!running.get()){selectedPosition="Cone";refreshToggles()} }
        locRow.addView(locationPort,LinearLayout.LayoutParams(0,dp(42),1f))
        locRow.addView(dividerBetween(),LinearLayout.LayoutParams(dp(1),dp(35)))
        locRow.addView(locationCone,LinearLayout.LayoutParams(0,dp(42),1f))
        locationRoom=button("Room") { if(!running.get()){selectedPosition="Room";refreshToggles()} }
        locRow.addView(dividerBetween(),LinearLayout.LayoutParams(dp(1),dp(35)))
        locRow.addView(locationRoom,LinearLayout.LayoutParams(0,dp(42),1f))
        val modeRow=segmentRow();right.addView(modeRow)
        modeAuto=button("Auto") { if(!running.get()){selectedMode="Automatic sweep";refreshToggles()} }
        modeManual=button("Manual") { if(!running.get()){selectedMode="Manual frequency";refreshToggles()} }
        modeRow.addView(modeAuto,LinearLayout.LayoutParams(0,dp(42),1f))
        modeRow.addView(dividerBetween(),LinearLayout.LayoutParams(dp(1),dp(35)))
        modeRow.addView(modeManual,LinearLayout.LayoutParams(0,dp(42),1f))
        refreshToggles()
        val knobs=row();face.addView(knobs)
        val frequencyKnob=RotaryKnob("FREQUENCY",5,120,40,"Hz") { manualHz=it; if(running.get() && selectedMode=="Manual frequency") {targetHz.set(it);main.post { frequencyReadout.text="$it Hz" }} }
        val levelKnob=RotaryKnob("TONE LEVEL",1,20,6,"%") { amplitudePercent=it;amplitudeFraction=it/100.0 }
        knobs.addView(frequencyKnob,LinearLayout.LayoutParams(0,dp(172),1f))
        val display=column().apply {
            background=chromeBezel(18);elevation=dp(5).toFloat()
            setPadding(dp(7),dp(13),dp(7),dp(12))
            gravity=android.view.Gravity.CENTER
        }
        display.addView(label("CURRENT FREQUENCY",10f,Color.rgb(108,249,242)).apply {
            letterSpacing=.025f;typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
            setPadding(0,dp(5),0,0)
        })
        frequencyReadout=label("0 Hz",34f,Color.rgb(64,255,246)).apply {
            typeface=Typeface.create("sans-serif-light",Typeface.NORMAL)
            letterSpacing=.035f
            setShadowLayer(dp(5).toFloat(),0f,0f,Color.rgb(0,135,143))
            setLayerType(View.LAYER_TYPE_SOFTWARE,null)
            setPadding(0,dp(2),0,dp(2))
        }
        display.addView(frequencyReadout)
        knobs.addView(display,LinearLayout.LayoutParams(0,dp(124),1.3f))
        knobs.addView(levelKnob,LinearLayout.LayoutParams(0,dp(172),1f))
        face.addView(instrumentButton("50 Hz CALIBRATION (background + tone)") {
            if(!running.get()){calibrationNext=true;begin()}
        },LinearLayout.LayoutParams(-1,dp(45)))
        val rangeRow=row();face.addView(rangeRow)
        val startOptions=listOf(5,10,15,20,25,30,40)
        val endOptions=listOf(40,60,80,90,100,120)
        val startSpinner=Spinner(this);val endSpinner=Spinner(this)
        fun setupSpinner(spinner:Spinner, options:List<Int>, default:Int, onValue:(Int)->Unit) {
            spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options.map { "$it Hz" })
            spinner.setSelection(options.indexOf(default))
            spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) {
                    if(!running.get())onValue(options[position]) else spinner.setSelection(options.indexOf(if(spinner===startSpinner)sweepStart else sweepEnd))
                }
            }
        }
        val startCol=column();startCol.addView(label("SWEEP START",11f));startCol.addView(startSpinner)
        val endCol=column();endCol.addView(label("SWEEP END",11f));endCol.addView(endSpinner)
        rangeRow.addView(startCol,LinearLayout.LayoutParams(0,-2,1f));rangeRow.addView(endCol,LinearLayout.LayoutParams(0,-2,1f))
        rangeLabel=label("25–90 Hz · 1 Hz fine sweep · click-reduced continuous tone",11f)
        face.addView(rangeLabel)
        fun updateRange() { rangeLabel.text="$sweepStart–$sweepEnd Hz · 1 Hz fine sweep · click-reduced continuous tone" }
        setupSpinner(startSpinner,startOptions,25) { sweepStart=it;updateRange() }
        setupSpinner(endSpinner,endOptions,90) { sweepEnd=it;updateRange() }
        face.addView(label("Keep gain and microphone placement consistent. Stop for excessive excursion.",11f))
        runButton=instrumentButton("RUN SELECTED TEST") { begin() };face.addView(runButton,LinearLayout.LayoutParams(-1,dp(52)))
        stopButton=instrumentButton("STOP AUDIO / TEST") { running.set(false);toneEnabled.set(false) }.apply { isEnabled=false }
        face.addView(stopButton,LinearLayout.LayoutParams(-1,dp(52)))
        status=label("Ready. Select location and run a test.",12f);face.addView(status)
        val responseFrame=column().apply {
            background=chromeBezel(20);setPadding(dp(8),dp(7),dp(8),dp(10));elevation=dp(3).toFloat()
        }
        responseFrame.addView(label("FREQUENCY RESPONSE",15f,Color.rgb(240,244,238)).apply {
            letterSpacing=.14f;typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
        })
        plot=ResponsePlot();responseFrame.addView(plot,LinearLayout.LayoutParams(-1,dp(258)))
        face.addView(responseFrame)
        face.addView(View(this),LinearLayout.LayoutParams(-1,dp(9)))
        val historyFrame=column().apply {
            background=chromeBezel(17);setPadding(dp(8),dp(7),dp(8),dp(9));elevation=dp(2).toFloat()
        }
        historyFrame.addView(label("MEASUREMENT HISTORY",14f,Color.rgb(236,246,242)).apply { letterSpacing=.08f })
        historyFrame.addView(label("Select saved tests to compare",11f,Color.rgb(116,212,207)).apply { setPadding(0,0,0,dp(5)) })
        historyArea=column();historyFrame.addView(historyArea)
        face.addView(historyFrame)
        val actions=row().apply { setPadding(0,dp(8),0,dp(5)) };face.addView(actions)
        actions.addView(instrumentButton("SHARE CSV") { shareCsv() },LinearLayout.LayoutParams(0,dp(54),1f))
        actions.addView(instrumentButton("CLEAR ACTIVE") { if(!running.get()) { activeSession=null; refreshAll() } },LinearLayout.LayoutParams(0,dp(54),1f))
        actions.addView(instrumentButton("DELETE SAVED") { if(!running.get()) confirmDelete() },LinearLayout.LayoutParams(0,dp(54),1f))
        val comparisonFrame=column().apply {
            background=chromeBezel(17);setPadding(dp(8),dp(7),dp(8),dp(10));elevation=dp(2).toFloat()
        }
        comparisonFrame.addView(label("MEASUREMENT COMPARISON",14f,Color.rgb(236,246,242)).apply { letterSpacing=.06f })
        comparisonArea=column();comparisonFrame.addView(comparisonArea)
        face.addView(comparisonFrame)
        output=label("",11f);face.addView(output)
        refreshAll()
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10)
    }

    private fun confirmDelete() {
        android.app.AlertDialog.Builder(this).setTitle("Delete saved tests?")
            .setMessage("Delete selected tests? If none are selected, delete all saved tests. This cannot be undone.")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete") { _,_->
                if(selectedSessionIds.isEmpty()) sessions.clear() else sessions.removeAll { it.id in selectedSessionIds }
                selectedSessionIds.clear();activeSession=null;saveSessions();refreshAll()
            }.show()
    }
    private fun refreshAll() { if(!::plot.isInitialized)return;refreshHistory();refreshComparison();plot.invalidate() }
    private fun refreshHistory() {
        historyArea.removeAllViews()
        if(sessions.isEmpty()) {historyArea.addView(label("No saved measurements yet.",12f,Color.rgb(178,193,192)));return}
        sessions.asReversed().forEach { session ->
            val check=CheckBox(this).apply {
                text="${session.location} · ${session.started} · ${session.points.size} points"
                textSize=12f;setTextColor(Color.rgb(221,237,235));isChecked=session.id in selectedSessionIds
                buttonTintList=android.content.res.ColorStateList.valueOf(teal)
                setOnCheckedChangeListener { _,checked-> if(checked) selectedSessionIds.add(session.id) else selectedSessionIds.remove(session.id);refreshComparison();plot.invalidate() }
            }
            historyArea.addView(check)
        }
    }
    private fun refreshComparison() {
        comparisonArea.removeAllViews()
        val chosen=sessions.filter { it.id in selectedSessionIds }
        if(chosen.isEmpty()){comparisonArea.addView(label("Select saved tests above to view their values and differences.",12f,Color.rgb(178,193,192)));return}
        val heading=if(chosen.size==2) "Hz     Test 1       Test 2      Δ dB" else "Hz     " + chosen.joinToString("    ") { "#${it.id}" }
        comparisonArea.addView(label(heading,11f,Color.rgb(54,245,232)).apply {
            background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(Color.rgb(0,63,67),Color.rgb(3,31,35)))
            typeface=Typeface.MONOSPACE
        })
        val allHz=chosen.flatMap { it.points.map(Result::hz) }.distinct().sorted()
        allHz.forEach { hz ->
            val values=chosen.map { s->s.points.lastOrNull { it.hz==hz }?.db }
            val line=buildString {
                append(String.format(Locale.US,"%2d",hz))
                values.forEach { append("     "+(it?.let { n->fmt(n) }?:"—")) }
                if(chosen.size==2) {
                    val a=values[0];val b=values[1]
                    append("      "+(if(a!=null && b!=null) String.format(Locale.US,"%+.1f",b-a) else "—"))
                }
            }
            comparisonArea.addView(label(line,11f,Color.rgb(213,233,230)).apply {
                typeface=Typeface.MONOSPACE;gravity=android.view.Gravity.START
                if(hz%2==0)setBackgroundColor(Color.rgb(14,34,38))
            })
        }
    }
    private fun saveSessions() {
        val arr=JSONArray()
        sessions.forEach { s->
            val obj=JSONObject().put("id",s.id).put("location",s.location).put("started",s.started)
            val pts=JSONArray();s.points.forEach { r->pts.put(JSONObject().put("hz",r.hz).put("db",r.db).put("rms",r.rmsDb).put("timestamp",r.timestamp)) }
            obj.put("points",pts);arr.put(obj)
        }
        getPreferences(MODE_PRIVATE).edit().putString("sessions_v12",arr.toString()).apply()
    }
    private fun loadSessions() {
        try {
            val arr=JSONArray(getPreferences(MODE_PRIVATE).getString("sessions_v12","[]"))
            for(i in 0 until arr.length()) {
                val obj=arr.getJSONObject(i);val s=Session(obj.getInt("id"),obj.getString("location"),obj.getString("started"))
                val pts=obj.getJSONArray("points")
                for(j in 0 until pts.length()) { val r=pts.getJSONObject(j);s.points.add(Result(s.location,r.getInt("hz"),r.getDouble("db"),r.getDouble("rms"),r.getString("timestamp"))) }
                sessions.add(s)
            }
            nextSessionId=(sessions.maxOfOrNull { it.id }?:0)+1
        } catch(_:Exception) { sessions.clear() }
    }
    inner class AccentLinesView:View(this) {
        private val brush=Paint(3)
        override fun onDraw(c:Canvas) {
            val y=height*.57f
            brush.style=Paint.Style.STROKE;brush.strokeCap=Paint.Cap.ROUND
            brush.strokeWidth=dp(2).toFloat();brush.color=Color.rgb(10,28,30)
            c.drawLine(0f,y,width.toFloat(),y,brush)
            brush.strokeWidth=dp(1).toFloat();brush.color=Color.rgb(0,120,119)
            c.drawLine(0f,y-dp(2),width.toFloat(),y-dp(2),brush)
            brush.style=Paint.Style.FILL
        }
    }
    inner class ScrewView:View(this) {
        private val p=Paint(3)
        override fun onDraw(c:Canvas) {
            val x=width/2f;val y=height/2f;val r=min(width,height)*.37f
            p.style=Paint.Style.FILL;p.color=Color.rgb(62,56,48);c.drawCircle(x+1,y+2,r+2,p)
            p.shader=LinearGradient(x-r,y-r,x+r,y+r,intArrayOf(Color.rgb(255,254,248),Color.rgb(109,111,108),Color.rgb(231,230,222),Color.rgb(73,78,78)),null,Shader.TileMode.CLAMP)
            c.drawCircle(x,y,r,p);p.shader=null
            p.color=Color.rgb(42,46,46);p.strokeWidth=dp(2).toFloat();p.strokeCap=Paint.Cap.ROUND
            c.drawLine(x-r*.46f,y-r*.46f,x+r*.46f,y+r*.46f,p)
            c.drawLine(x+r*.46f,y-r*.46f,x-r*.46f,y+r*.46f,p)
        }
    }
    inner class RotaryKnob(title:String,private val low:Int,private val high:Int,initial:Int,private val unit:String,private val changed:(Int)->Unit):View(this) {
        private val paint=Paint(3);private var value=initial;private val name=title
        override fun onDraw(c:Canvas) {
            super.onDraw(c);val w=width.toFloat();val h=height.toFloat();val cx=w/2;val cy=h*.50f;val r=min(w*.38f,h*.32f)
            paint.style=Paint.Style.FILL;paint.color=ink;paint.textSize=dp(11).toFloat();paint.typeface=Typeface.DEFAULT_BOLD;paint.textAlign=Paint.Align.CENTER;c.drawText(name,cx,dp(17).toFloat(),paint)
            // Etched tick marks around the 270-degree travel, without changing touch mapping.
            paint.shader=null;paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(1).toFloat();paint.color=Color.rgb(25,32,34)
            for (i in 0..20) {
                val a=Math.toRadians(135.0+i*13.5)
                c.drawLine(cx+cos(a).toFloat()*r*1.10f,cy+sin(a).toFloat()*r*1.10f,
                    cx+cos(a).toFloat()*r*1.23f,cy+sin(a).toFloat()*r*1.23f,paint)
            }
            paint.style=Paint.Style.FILL;paint.color=Color.argb(70,0,0,0)
            c.drawCircle(cx+dp(1),cy+dp(2),r*.97f,paint)
            paint.shader=LinearGradient(cx-r,cy-r,cx+r,cy+r,intArrayOf(
                Color.rgb(20,26,28),Color.rgb(185,189,183),Color.rgb(32,39,40),Color.rgb(99,107,106)),null,Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,r*.96f,paint);paint.shader=null
            paint.color=Color.rgb(36,49,51);c.drawCircle(cx,cy,r*.85f,paint)
            paint.shader=LinearGradient(cx-r,cy-r,cx+r,cy+r,intArrayOf(
                Color.rgb(248,244,229),Color.rgb(112,119,120),Color.rgb(223,220,210)),null,Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,r*.81f,paint);paint.shader=null
            paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(4).toFloat();paint.color=Color.rgb(34,43,45)
            c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,270f,false,paint)
            paint.color=teal;paint.setShadowLayer(dp(3).toFloat(),0f,0f,teal)
            c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,270f*(value-low)/(high-low),false,paint)
            paint.clearShadowLayer()
            paint.style=Paint.Style.FILL
            paint.shader=SweepGradient(cx,cy,intArrayOf(
                Color.rgb(110,115,113),Color.rgb(250,250,245),Color.rgb(174,177,175),
                Color.rgb(234,235,231),Color.rgb(92,99,98),Color.rgb(110,115,113)),null)
            c.drawCircle(cx,cy,r*.79f,paint);paint.shader=null
            // Subtle lathe work, not heavy concentric N64-style rings.
            paint.style=Paint.Style.STROKE;paint.strokeWidth=.28f
            for (i in 1..45) {
                paint.color=Color.argb(if(i%4==0) 11 else 5,26,35,36)
                c.drawCircle(cx,cy,r*(.22f+i*.012f),paint)
            }
            paint.style=Paint.Style.FILL
            paint.shader=RadialGradient(cx-r*.20f,cy-r*.23f,r*.95f,
                intArrayOf(Color.argb(75,255,255,255),Color.TRANSPARENT,Color.argb(32,5,15,18)),null,Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,r*.78f,paint);paint.shader=null
            val angle=Math.toRadians((135.0+270.0*(value-low)/(high-low)))
            paint.color=ink;paint.strokeWidth=dp(3).toFloat();paint.strokeCap=Paint.Cap.ROUND
            c.drawLine(cx+cos(angle).toFloat()*r*.35f,cy+sin(angle).toFloat()*r*.35f,cx+cos(angle).toFloat()*r*.67f,cy+sin(angle).toFloat()*r*.67f,paint)
            // Recessed numeric plaque directly below each knob.
            val plaqueW=dp(66).toFloat();val plaqueTop=h-dp(30).toFloat()
            paint.style=Paint.Style.FILL;paint.shader=LinearGradient(cx,plaqueTop,cx,h,
                intArrayOf(Color.rgb(183,190,186),Color.rgb(39,49,50),Color.rgb(217,217,209)),null,Shader.TileMode.CLAMP)
            c.drawRoundRect(cx-plaqueW/2,plaqueTop,cx+plaqueW/2,h-dp(1).toFloat(),dp(10).toFloat(),dp(10).toFloat(),paint)
            paint.shader=null;paint.color=Color.rgb(6,24,28)
            c.drawRoundRect(cx-plaqueW/2+dp(3),plaqueTop+dp(3),cx+plaqueW/2-dp(3),h-dp(4).toFloat(),dp(7).toFloat(),dp(7).toFloat(),paint)
            paint.textSize=dp(13).toFloat();paint.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
            paint.color=Color.rgb(81,241,228);paint.textAlign=Paint.Align.CENTER
            c.drawText("$value $unit",cx,h-dp(10),paint)
        }
        override fun onTouchEvent(e:MotionEvent):Boolean {
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // Claim the gesture before ScrollView can intercept vertical knob drags.
                    parent?.requestDisallowInterceptTouchEvent(true)
                    if(running.get() && (selectedMode!="Manual frequency" || name!="FREQUENCY")) return true
                    updateFromTouch(e)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    if(running.get() && (selectedMode!="Manual frequency" || name!="FREQUENCY")) return true
                    updateFromTouch(e)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return true
                }
            }
            return true
        }
        private fun updateFromTouch(e:MotionEvent) {
            val dx=e.x-width/2f;val dy=e.y-height*.50f
            var angle=(Math.toDegrees(atan2(dy.toDouble(),dx.toDouble()))+360)%360
            // Active arc: 135..360 then 0..45 degrees. The bottom 90-degree
            // gap (45..135) is NOT part of the arc. Clamp to the nearest end
            // rather than wrapping a small movement below minimum to maximum.
            val fraction = when {
                angle >= 135.0 -> (angle - 135.0) / 270.0
                angle <= 45.0 -> (angle + 225.0) / 270.0
                angle < 90.0 -> 1.0  // Gap adjacent to maximum
                angle > 90.0 -> 0.0  // Gap adjacent to minimum
                else -> if (value - low <= high - value) 0.0 else 1.0
            }
            val newValue=(low+fraction*(high-low)).roundToInt().coerceIn(low,high)
            if(newValue!=value) { value=newValue;changed(value);invalidate() }
        }
    }
    inner class ResponsePlot:View(this) {
        private val p=Paint(3)
        init { setLayerType(View.LAYER_TYPE_SOFTWARE,null) }
        override fun onDraw(c:Canvas) {
            super.onDraw(c);c.drawColor(ink)
            val left=dp(39).toFloat();val right=width-dp(12).toFloat();val top=dp(18).toFloat();val bottom=height-dp(30).toFloat()
            p.textSize=dp(10).toFloat();p.typeface=Typeface.MONOSPACE;p.style=Paint.Style.FILL;p.color=Color.LTGRAY
            val chosen=sessions.filter { it.id in selectedSessionIds }.ifEmpty { activeSession?.let { listOf(it) }?:sessions.takeLast(1) }
            val allPoints=chosen.flatMap { it.points }
            val minDb=kotlin.math.floor(min(-40.0,(allPoints.minOfOrNull { it.db } ?: -40.0)-5.0)/10.0).toInt()*10
            val maxDb=10
            val minHz=min(sweepStart,allPoints.minOfOrNull { it.hz }?:sweepStart).coerceAtMost(25)
            val maxHz=max(sweepEnd,allPoints.maxOfOrNull { it.hz }?:sweepEnd).coerceAtLeast(90)
            for(db in minDb..maxDb step 10) {
                val y=bottom-(db-minDb).toFloat()/(maxDb-minDb)*(bottom-top)
                p.color=Color.rgb(26,88,89);p.strokeWidth=1f;c.drawLine(left,y,right,y,p)
                p.color=Color.LTGRAY;p.textAlign=Paint.Align.RIGHT;c.drawText("$db",left-dp(5),y+dp(3),p)
            }
            val tickStep=if(maxHz-minHz>90)20 else 10
            for(hz in minHz..maxHz step tickStep) {
                val x=left+(hz-minHz).toFloat()/(maxHz-minHz)*(right-left)
                p.color=Color.rgb(26,88,89);c.drawLine(x,top,x,bottom,p)
                p.color=Color.LTGRAY;p.textAlign=Paint.Align.CENTER;c.drawText("$hz",x,bottom+dp(15),p)
            }
            val palette=intArrayOf(teal,Color.rgb(255,184,58),Color.rgb(130,175,255),Color.rgb(238,123,192),Color.WHITE)
            chosen.forEachIndexed { index,s ->
                val pts=s.points.sortedBy { it.hz };if(pts.size<2)return@forEachIndexed
                p.color=when(s.location) {
                    "Port" -> teal
                    "Cone" -> Color.rgb(255,180,66)
                    "Room" -> Color.rgb(129,169,250)
                    else -> palette[index%palette.size]
                }
                p.strokeWidth=dp(2).toFloat();p.style=Paint.Style.STROKE;p.strokeJoin=Paint.Join.ROUND;p.strokeCap=Paint.Cap.ROUND
                val path=Path();pts.forEachIndexed { i,r->
                    val x=left+(r.hz-minHz).toFloat()/(maxHz-minHz)*(right-left)
                    val y=bottom-((r.db-minDb)/(maxDb-minDb)).coerceIn(0.0,1.0).toFloat()*(bottom-top)
                    if(i==0)path.moveTo(x,y) else path.lineTo(x,y)
                }
                p.setShadowLayer(dp(2).toFloat(),0f,0f,p.color)
                c.drawPath(path,p);p.clearShadowLayer();p.style=Paint.Style.FILL
                p.textSize=dp(10).toFloat();p.textAlign=Paint.Align.LEFT;c.drawText("${s.location} #${s.id}",left+dp(6),top+dp(12+index*13),p)
            }
            p.style=Paint.Style.FILL;p.color=Color.LTGRAY;p.textSize=dp(10).toFloat();p.textAlign=Paint.Align.CENTER;c.drawText("Frequency (Hz)",(left+right)/2,height-dp(3).toFloat(),p)
        }
    }

    private fun begin() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10);return}
        if(!running.compareAndSet(false,true))return
        val loc=if(calibrationNext) "Calibration" else selectedPosition
        calibrationNext=false
        if(loc!="Calibration" && selectedMode=="Automatic sweep" && sweepStart>=sweepEnd) {
            running.set(false);Toast.makeText(this,"Sweep start must be below sweep end",Toast.LENGTH_LONG).show();return
        }
        val manualMode=loc!="Calibration" && selectedMode=="Manual frequency"
        val chosen=if(loc=="Calibration") listOf(50) else if(!manualMode) (sweepStart..sweepEnd).toList() else listOf(manualHz)
        if(sweepStart<20 && !manualMode && loc!="Calibration") Toast.makeText(this,"Below 20 Hz: start quietly; monitor cone excursion. Phone microphone accuracy is limited.",Toast.LENGTH_LONG).show()
        runButton.isEnabled=false;stopButton.isEnabled=true
        val session=Session(nextSessionId++,loc,SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date()))
        activeSession=session
        sessions.add(session);selectedSessionIds.clear();selectedSessionIds.add(session.id);refreshAll()
        thread(name="SubTuneMeasurement") {
            try {
                report("Starting in 5 seconds. Check low volume and microphone placement.")
                for(i in 5 downTo 1){if(!running.get())break; report("Starting in $i…");Thread.sleep(1000)}
                if(running.get()) {
                    if(loc=="Calibration") {
                        report("Calibration: silence/background at 50 Hz (3 seconds)")
                        val bg=measureOnly(50,3000)
                        if(running.get()) {
                            report("Calibration: playing 50 Hz")
                            val sig=playAndMeasure(50)
                            if(sig!=null){report("Calibration 50 Hz: background ${fmt(bg.first)} dBFS, tone ${fmt(sig.first)} dBFS, difference ${fmt(sig.first-bg.first)} dB (relative only). Check for clean sound.")}
                        }
                    } else {
                        startContinuousTone(chosen.first())
                        try {
                            if(manualMode) {
                                report("$loc manual tone: turn frequency knob; press STOP to finish")
                                while(running.get()) {
                                    val hz=targetHz.get()
                                    main.post { frequencyReadout.text="$hz Hz" }
                                    val reading=measureOnly(hz,700)
                                    if(running.get() && hz==targetHz.get()) {
                                        val result=Result(loc,hz,reading.first,reading.second,SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date()))
                                        synchronized(results){results.add(result);session.points.removeAll { it.hz==hz };session.points.add(result)}
                                        main.post { plot.invalidate();refreshComparison() }
                                    }
                                }
                            } else for(hz in chosen) {
                                if(!running.get())break
                                report("$loc: measuring $hz Hz (${chosen.indexOf(hz)+1}/${chosen.size})")
                                main.post { frequencyReadout.text="$hz Hz" }
                                targetHz.set(hz)
                                // Frequency glides over ~100 ms; allow Bluetooth and speaker response to settle.
                                Thread.sleep(450)
                                val reading=if(running.get()) measureOnly(hz,900) else null
                                if(reading!=null && running.get()) {
                                    val result=Result(loc,hz,reading.first,reading.second,SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date()))
                                    synchronized(results){results.add(result);session.points.add(result)}
                                    main.post { plot.invalidate();refreshComparison() }
                                }
                            }
                        } finally { stopContinuousTone() }
                        if(running.get()) report("$loc complete. Review results or measure the other location at the SAME gain.")
                    }
                }
            } catch(e:Exception){report("Test error: ${e.message ?: e.javaClass.simpleName}")}
            finally {running.set(false);releaseAudio();main.post {
                if(session.points.isEmpty()) {sessions.remove(session);selectedSessionIds.remove(session.id)}
                saveSessions();refreshAll();runButton.isEnabled=true;stopButton.isEnabled=false;frequencyReadout.text="0 Hz"
            } }
        }
    }

    // A single AudioTrack stays open throughout the sweep, preserving phase continuity.
    // A short frequency glide and gain envelope prevent hard discontinuities/clicks.
    private fun startContinuousTone(initialHz:Int) {
        val minBytes=AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0)throw IllegalStateException("Audio output unavailable")
        val player=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(max(minBytes,8192)).build()
        tone=player
        targetHz.set(initialHz)
        toneEnabled.set(true)
        toneWriter=thread(name="SubTuneContinuousTone") {
            var phase=0.0
            var currentHz=initialHz.toDouble()
            var gain=0.0
            val data=ShortArray(2048)
            try {
                player.play()
                while(running.get() && toneEnabled.get()) {
                    for(i in data.indices step 2) {
                        val desired=targetHz.get().toDouble()
                        currentHz+=(desired-currentHz)/ (sampleRate*0.10)
                        gain+=(1.0-gain)/(sampleRate*0.03)
                        val sample=(sin(phase)*amplitudeFraction*gain*32767.0).roundToInt().coerceIn(-32767,32767).toShort()
                        data[i]=sample;data[i+1]=sample
                        phase+=2.0*PI*currentHz/sampleRate
                        if(phase>=2.0*PI)phase-=2.0*PI
                    }
                    val wrote=player.write(data,0,data.size,AudioTrack.WRITE_BLOCKING)
                    if(wrote<0)break
                }
                // Fade out instead of abruptly stopping the output waveform.
                for(k in 0 until 5) {
                    for(i in data.indices step 2) {
                        gain*=0.998
                        val sample=(sin(phase)*amplitudeFraction*gain*32767.0).roundToInt().toShort()
                        data[i]=sample;data[i+1]=sample
                        phase+=2.0*PI*currentHz/sampleRate
                        if(phase>=2.0*PI)phase-=2.0*PI
                    }
                    if(player.write(data,0,data.size,AudioTrack.WRITE_BLOCKING)<0)break
                }
            } catch(_:Exception) {} 
        }
    }

    private fun stopContinuousTone() {
        toneEnabled.set(false)
        try { toneWriter?.join(700) } catch(_:InterruptedException) { Thread.currentThread().interrupt() }
        toneWriter=null
        val player=tone
        tone=null
        try { player?.pause();player?.flush();player?.release() } catch(_:Exception) {}
    }

    private fun playAndMeasure(hz:Int):Pair<Double,Double>? {
        startContinuousTone(hz)
        return try {
            Thread.sleep(1200)
            if(running.get())measureOnly(hz,2200) else null
        } finally { stopContinuousTone() }
    }

    private fun measureOnly(hz:Int,durationMs:Int):Pair<Double,Double> {
        val source=if(Build.VERSION.SDK_INT>=24 && (getSystemService(AUDIO_SERVICE) as AudioManager).getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED)=="true") MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val min=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(min<=0)throw IllegalStateException("Microphone recording unavailable")
        val mic=AudioRecord(source,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,max(min,8192))
        recorder=mic
        if(mic.state!=AudioRecord.STATE_INITIALIZED){mic.release();throw IllegalStateException("Cannot initialize microphone")}
        val audioManager=getSystemService(AUDIO_SERVICE) as AudioManager
        audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.type==AudioDeviceInfo.TYPE_BUILTIN_MIC }?.let { mic.setPreferredDevice(it) }
        val block=ShortArray(2048)
        var n=0L;var sum=0.0;var re=0.0;var im=0.0
        val step=2*PI*hz/sampleRate
        try {
            mic.startRecording()
            val deadline=System.nanoTime()+durationMs*1_000_000L
            while(running.get() && System.nanoTime()<deadline) {
                val count=mic.read(block,0,block.size,AudioRecord.READ_BLOCKING)
                if(count<0)throw IllegalStateException("Mic read error $count")
                for(i in 0 until count) {
                    val x=block[i].toDouble()/32768.0
                    val a=step*n
                    re+=x*cos(a);im+=x*sin(a);sum+=x*x;n++
                }
            }
        } finally {try{mic.stop()}catch(_:Exception){};mic.release();recorder=null}
        if(n==0L)return Pair(-120.0,-120.0)
        val peak=sqrt(re*re+im*im)*2/n
        val rms=sqrt(sum/n)
        return Pair(20*log10(max(peak,1e-6)),20*log10(max(rms,1e-6)))
    }

    private fun report(s:String){main.post{status.text=s}}
    private fun fmt(v:Double)=String.format(Locale.US,"%.1f",v)
    private fun shareCsv(){
        if(running.get()){Toast.makeText(this,"Stop test before exporting",Toast.LENGTH_SHORT).show();return}
        val snapshot=sessions.flatMap { it.points }
        if(snapshot.isEmpty()){Toast.makeText(this,"No measurements to export",Toast.LENGTH_SHORT).show();return}
        val csv=buildString {
            append("location,frequency_hz,tone_dbfs,rms_dbfs,timestamp\n")
            snapshot.forEach{append("${it.location},${it.hz},${fmt(it.db)},${fmt(it.rmsDb)},${it.timestamp}\n")}
        }
        // Share text avoids needing FileProvider and works on current Android versions.
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"SubTune measurements.csv");putExtra(Intent.EXTRA_TEXT,csv)},"Share SubTune CSV"))
    }
    private fun releaseAudio(){stopContinuousTone();try{recorder?.stop();recorder?.release()}catch(_:Exception){};recorder=null}
    override fun onDestroy(){running.set(false);toneEnabled.set(false);super.onDestroy()}
}


