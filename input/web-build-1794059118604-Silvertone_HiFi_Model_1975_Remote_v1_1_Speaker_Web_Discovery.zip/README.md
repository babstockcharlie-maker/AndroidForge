# Silvertone Hi-Fi V1.0 — TLS Compatibility Diagnostics

AndroidForge / Android Studio source project, based on V0.9. All previous remote, speaker setup, styling, icon and diagnostic screens retained.

## New test

Receiver Diagnostics → **TLS COMPATIBILITY — V1.0** → **1 · DIAGNOSE TLS & CERTIFICATE**.

The app compares direct automatic TLS, direct TLS 1.2, a layered socket without SNI, and a layered socket with the receiver hostname. It reports handshake outcomes and, if supplied by the receiver, the observed certificate SHA-256 fingerprint. No HTTP requests are sent during these tests. If a certificate is observed, the existing explicit fingerprint approval can be used for read-only HTTPS GET inspection. This does not guarantee a successful handshake or establish a speaker-distance API.

Tap **COPY V1.0 TLS REPORT** and share it for analysis. Keep the previously working APK available. This source project has not been compiled or tested on the SR7013.

Known browser URL: https://192.168.0.3:10443/speakers/speakers.html# ; manual reference main FL/FR 3.23 m, separate 2ch FL/FR 2.52 m earlier. No live readings implemented.


## V1.1 speaker-page inspection
After TLS certificate inspection, review the fingerprint and use **3 · INSPECT SPEAKER PAGE — V1.1**, then **COPY V1.1 SPEAKER REPORT**. The inspection performs only certificate-pinned HTTPS GET requests to `/speakers/speakers.html` and up to 8 safe same-origin `.js` files explicitly referenced by that page. No JavaScript execution, form submissions, unknown API calls, or configuration writes. This is not yet live distance readback.
